import socket

from aether_rdk.addons.gripper.gripper_constants import (
    GRIPPER_ETHERNET_IP,
    GRIPPER_SOCKET_PORT,
    GripperCommands,
    GripperResponses,
)


class GripperCommSocket:
    """
    A class representing a communication socket for controlling a gripper.

    Attributes:
        MAX_POSITION_ANGLE (int): The maximum position angle of the gripper.
        MIN_POSITION_ANGLE (int): The minimum position angle of the gripper.

    Methods:
        is_connect() -> bool:
            Check if the gripper communication socket is connected.
        connect() -> bool:
            Connects the socket to the gripper.
        disconnect() -> bool:
            Disconnects the socket from the gripper.
        move_gripper_to(angle:int) -> bool:
            Moves the gripper to the specified angle.
        reset_motor() -> bool:
            Resets the gripper motor.
        gripper_status() -> GripperStatus | tuple:
            Gets the status of the gripper.
        gripper_position() -> int | None:
            Gets the position of the gripper.
    """

    def __init__(self, gripper_ip, gripper_port):
        """
        Initializes a GripperCommSocket object.

        Args:
            gripper_ip (str): The IP address of the gripper.
            gripper_port (int): The port number of the gripper.
        """
        self.__socket = None
        self.__ip = gripper_ip
        self.__port = gripper_port
        self.__connected = False

        self.__MAX_TIME_RESPONSE = 15

        self.MAX_POSITION_ANGLE = 500
        self.MIN_POSITION_ANGLE = 175

    def __raw_gripper_status(self) -> str | None:
        """
        Sends a command to the gripper to get the raw status.

        Returns:
            str|None: The received raw status as a string, or None if not connected.
        """
        if self.__connected:
            try:
                command = str(GripperCommands.GRIPPER_STATUS)
                data = bytes(command, "utf-8")
                self.__socket.sendall(data)

                received_data = (self.__socket.recv(1024)).decode()

                return received_data

            except Exception as e:
                print(e)

    def is_connect(self) -> bool:
        """
        Check if the gripper communication socket is connected.

        Returns:
            bool: True if the socket is connected, False otherwise.
        """
        return self.__connected

    def connect(self) -> bool:
        """
        Connects the socket to the gripper.

        Returns:
            bool: True if the connection is successful, False otherwise.
        """
        if self.__connected:
            return True

        try:
            self.__socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.__socket.connect((self.__ip, self.__port))
            self.__socket.settimeout(self.__MAX_TIME_RESPONSE)
            self.__connected = True
            return True
        except Exception as e:
            print(e)
            return False

    def disconnect(self):
        """
        Disconnects the socket from the gripper.

        Returns:
            bool: True if the disconnection is successful, False otherwise.
        """
        if self.__connected:
            self.__socket.close()
            self.__connected = False
            return True
        return False

    def move_gripper_to(self, angle: int) -> bool:
        """
        Moves the gripper to the specified angle.

        Args:
            angle (int): The angle to move the gripper to any positions.
            0 - Close gripper
            1 - Open gripper
            2 - Forced Close Gripper
            3 - Stop Operation

        Returns:
            bool: True if the move is successful, False otherwise.
        """
        if not isinstance(angle, int):
            print("Expected int, but was received:", type(angle))
            return False

        if angle not in [0, 1, 2, 3]:
            print("Out of range value")
            return False

        if self.__connected:
            try:
                command = f"{GripperCommands.GRIPPER_MOVE} {angle}"
                data = bytes(command, "utf-8")
                self.__socket.sendall(data)

                received_data = (self.__socket.recv(1024)).decode()

                if str(GripperResponses.OK_MOVE_FINISH) in received_data:
                    return True
                elif str(GripperResponses.COMMAND_UNKNOWN) in received_data:
                    print("Unknown command received in gripper")
            except Exception as e:
                print(e)
                return False
        return False

    def reset_motor(self) -> bool:
        """
        Resets the gripper motor.

        Returns:
            bool: True if the motor reset is successful, False otherwise.
        """
        if self.__connected:
            try:
                command = str(GripperCommands.RESET_MOTOR)
                data = bytes(command, "utf-8")
                self.__socket.sendall(data)

                received_data = (self.__socket.recv(1024)).decode()

                if str(GripperResponses.RESET_FINISH) in received_data:
                    return True
            except Exception as e:
                print(e)
                return False
        return False

    def gripper_status(self) -> GripperResponses | tuple[GripperResponses, int]:
        """
        Gets the status of the gripper.

        Returns:
            GripperResponses|tuple[GripperResponses, int]: The status of the gripper as a GripperResponses enum value or a tuple
            containing the motor error status and the error code.
        """
        raw_status = self.__raw_gripper_status()
        if raw_status is None:
            return GripperResponses.NOT_RESPONSE

        if str(GripperResponses.GRIPPER_OK) in raw_status:
            return GripperResponses.GRIPPER_OK
        else:
            try:
                elements = raw_status.split(":")
                if len(elements) == 2 and str(GripperResponses.MOTOR_IN_ERROR) in elements[0]:
                    return GripperResponses.MOTOR_IN_ERROR, int(elements[1])
            except Exception as e:
                print(e)
                return GripperResponses.UNKNOWN_RESPONSE

            return GripperResponses.UNKNOWN_ERROR

    def gripper_position(self) -> int | None:
        """
        Gets the position of the gripper.

        Returns:
            int|None: The position of the gripper as an integer, or None if the position cannot be determined.
        """
        raw_status = self.__raw_gripper_status()
        if not (raw_status is None):
            if str(GripperResponses.GRIPPER_OK) in raw_status:
                elements = raw_status.split(",")
                try:
                    pos = elements[1].split(":")[1]
                    return int(pos)
                except Exception as e:
                    print("Error in parser response:", e)


if __name__ == "__main__":
    gripper_obj = GripperCommSocket(GRIPPER_ETHERNET_IP, GRIPPER_SOCKET_PORT)
    print(gripper_obj.connect())
    print(gripper_obj.gripper_status())
    gripper_obj.reset_motor()
    gripper_obj.gripper_status()
    gripper_obj.move_gripper_to(500)
