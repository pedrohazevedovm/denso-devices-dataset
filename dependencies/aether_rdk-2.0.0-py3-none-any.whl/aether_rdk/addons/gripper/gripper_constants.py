from enum import Enum, auto

# Gripper static ip
GRIPPER_ETHERNET_IP = "192.168.160.230"

# Gripper communication socket port
GRIPPER_SOCKET_PORT = 19200


class GripperCommands(Enum):
    """
    Enum class representing the commands for the gripper.

    Attributes:
        GRIPPER_MOVE: The command string for moving the gripper.
        GRIPPER_STATUS: The command string for getting the gripper status.
        RESET_MOTOR: The command string for resetting the motor.
    """

    GRIPPER_MOVE = auto()
    GRIPPER_STATUS = auto()
    RESET_MOTOR = auto()

    def __str__(self) -> str:
        """
        Override std method to use the scope name of the enum value.

        Returns:
            str: The scope name of the enum value.
        """
        full_name = super().__str__()
        scope_name = full_name.split(".")[-1]
        return scope_name


class GripperResponses(Enum):
    """
    Enum class representing the different responses from the gripper.

    Attributes:
        OK_MOVE_FINISH: The response message indicating successful move.
        VALUE_OUT_OF_RANGE: The response message indicating value out of range.
        COMMAND_FORMAT_ERROR: The response message indicating command format error.
        MOTOR_IN_ERROR: The response message indicating motor error.
        GRIPPER_OK: The response message indicating gripper motor OK.
        COMMAND_UNKNOWN: The response message indicating unknown command.
        RESET_FINISH: The response message indicating motor reset finish.
        CONTROL_INTERFACE_IN_ERROR: The response message indicating control interface error.
        NOT_RESPONSE: Indicating that, the controller did not respond.
        UNKNOWN_ERROR: The response message indicating unknown error is returned to interface.
        UNKNOWN_RESPONSE: The response message indicating unknown response is returned to interface.
    """

    OK_MOVE_FINISH = auto()
    VALUE_OUT_OF_RANGE = auto()
    COMMAND_FORMAT_ERROR = auto()
    MOTOR_IN_ERROR = auto()
    GRIPPER_OK = auto()
    COMMAND_UNKNOWN = auto()
    RESET_FINISH = auto()
    CONTROL_INTERFACE_IN_ERROR = auto()
    NOT_RESPONSE = auto()
    UNKNOWN_ERROR = auto()
    UNKNOWN_RESPONSE = auto()

    def __str__(self) -> str:
        """
        Override std method to use the scope name of the enum value.

        Returns:
            str: The scope name of the enum value.
        """
        full_name = super().__str__()
        scope_name = full_name.split(".")[-1]
        return scope_name
