"""
connect_denso.py

This module defines the `ConnectDenso` class, which facilitates the connection and communication with Denso robots via
the BCAPClient interface.
It provides methods for setting connection parameters, establishing a connection, and disconnecting from the robot.
"""

from aether_rdk.bcap.bcapclient import BCAPClient


class ConnectDenso:
    """
    A class to manage the connection and communication with Denso robots using the BCAP protocol.
    """

    def __init__(self, ip_address, port=5007, timeout=2000):
        """
        Initialize the ConnectDenso object.

        Args:
            ip_address (str): IP address of the robot controller.
            port (int): Communication port (default is 5007).
            timeout (int): Timeout for communication in milliseconds (default is 2000 ms).
        """
        self.ip_address = ip_address
        self.port = port
        self.timeout = timeout
        self.parameters = None
        self.bcap_client = None
        self.controller_handle = None
        self.robot_handle = None

    def set_parameters(self, name="", provider="CaoProv.DENSO.RC8", machine="", option="Server=192.168.160.226"):
        """
        Set the parameters required for connecting to the robot controller.

        Args:
            name (str): Name of the controller (default is an empty string).
            provider (str): Provider name (default is 'CaoProv.DENSO.RC8').
            machine (str): Machine name (default is an empty string).
            option (str): Option for the connection, such as the server IP (default is 'Server=192.168.160.226').

        Returns:
            list: A list containing the set parameters.

        Examples:
            >>> connect = ConnectDenso("192.168.160.226")
            >>> connect.set_parameters(name="", provider="CaoProv.DENSO.RC8", machine="", option="Server=192.168.160.226")
            ['', 'CaoProv.DENSO.RC8', '', 'Server=192.168.160.226']
        """
        self.parameters = [name, provider, machine, option]

    def connect_robot(self):
        """
        Establish a connection to the Denso robot controller.

        This method initializes the BCAPClient, connects to the robot controller,
        and retrieves a handle to the robot for executing commands.

        Returns:
            tuple: A tuple containing:
                - bcap_client (BCAPClient): The BCAP client object for communication.
                - robot_handle (object): The robot handle used to control the robot.

        Raises:
            Exception: If any part of the connection process fails.

        Examples:
            >>> connect = ConnectDenso("192.168.160.226")
            >>> connect.set_parameters()
            >>> bcap_client, robot_handle = connect.connect_robot()
        """
        # Connection processing of tcp communication
        self.bcap_client = BCAPClient(self.ip_address, self.port, self.timeout)
        self.bcap_client.service_start("")

        # Connect to RC8 (RC8 provider)
        self.controller_handle = self.bcap_client.controller_connect(
            self.parameters[0], self.parameters[1], self.parameters[2], self.parameters[3]
        )

        # Get Robot Object robot_handle
        self.robot_handle = self.bcap_client.controller_get_robot(self.controller_handle, "Arm", "")

        # TakeArm
        self.bcap_client.robot_execute(self.robot_handle, "TakeArm", [0, 0])

        return self.bcap_client, self.robot_handle

    def disconnect_robot(self, command, param):
        """
        Safely disconnect from the robot controller and release resources.

        Args:
            command (str): Command to execute before releasing the robot (e.g., 'GiveArm').
            param (list): Parameters required for the command.

        Raises:
            Exception: If an error occurs during the disconnection process.

        Examples:
            >>> connect = ConnectDenso("192.168.160.226")
            >>> bcap_client, robot_handle = connect.connect_robot()
            >>> connect.disconnect_robot(command="GiveArm", param=[])
        """
        # Give Arm
        self.bcap_client.robot_exec(self.robot_handle, command, param)

        # Disconnect
        if self.robot_handle != 0:
            self.bcap_client.robot_release(self.robot_handle)

        if self.controller_handle != 0:
            self.bcap_client.controller_disconnect(self.controller_handle)

        self.bcap_client.service_stop()
