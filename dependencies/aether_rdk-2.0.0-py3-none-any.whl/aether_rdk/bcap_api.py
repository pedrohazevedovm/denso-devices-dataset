from time import sleep

from aether_rdk.bcap.action_denso import ActionDenso
from aether_rdk.bcap.connect_denso import ConnectDenso


class BCAPAPI:
    """
    A class to manage robot connections, actions, and movement for different robot types.

    Attributes:
        ip_address (str): The IP address of the robot.
        robot_type (str): The type of the robot (e.g., "denso", "test").
        robot_instance (object): Instance of the connected robot.
        robot_handle (object): Handle of the connected robot.
        connection_instance (object): Connection instance for the robot.
        action_object (object): Action instance to control robot-specific actions.
    """

    def __init__(self, ip_address, robot_type):
        """
        Initializes the BCAPAPI class.

        Args:
            ip_address (str): The IP address of the robot.
            robot_type (str): The type of the robot (e.g., "denso", "test").
        """
        self.ip_address = ip_address
        self.robot_type = robot_type

        # This attribute is used to store the general robot instance
        self.robot_instance = None
        self.robot_handle = None

        # This attribute is used to store the general connection instance
        self.connection_instance = None

        # This attribute is used to store the general action instance
        self.action_object = None

    def connect_robot(self):
        """
        Connects to the robot based on its type.

        Returns:
            bool: True if the connection is successful, False otherwise.
        """
        if self.robot_type == "denso":
            try:
                self.connection_instance = ConnectDenso(self.ip_address)
                self.connection_instance.set_parameters(option="Server=" + self.ip_address)
                self.robot_instance, self.robot_handle = self.connection_instance.connect_robot()

                # Create an action object
                self.action_object = ActionDenso(self.robot_instance, self.robot_handle)

                return True

            except (Exception,):
                print("The connection attempt failed. Check the physical connection to the robot and try again later.")

                return False

        if self.robot_type == "test":
            sleep(1)
            return True

    def disconnect_robot(self):
        """
        Closes the connection with the robot.

        Returns:
            bool: True for successful disconnection (test robot only), None otherwise.
        """
        if self.robot_type == "denso":
            self.connection_instance.disconnect_robot()

        if self.robot_type == "test":
            sleep(1)
            return True

    def safe_disconnect(self):
        """
        Moves the robot to the home position and disconnects.

        Home position depends on the robot type:
            - Gen3: [0.0, 0.0, 0.0, 0.0, 0.0, 0.0] degrees.
            - Ned: [0.0, 0.3, -1.3, 0.0, 0.0, 0.0] radians.

        Returns:
            bool: True for test robot only, None otherwise.
        """
        if self.robot_type == "denso":
            self.action_object.move_to_zero()
            self.connection_instance.disconnect_robot()

        if self.robot_type == "test":
            sleep(1)
            return True

    # Motor methods
    def motor_on(self):
        """
        Turns the robot's motor on.

        Returns:
            bool: True for test robot only, None otherwise.
        """
        if self.robot_type == "denso":
            self.action_object.motor_on()

        if self.robot_type == "test":
            sleep(1)
            print("Motor on Tac Tac Tac")
            return True

    def motor_off(self):
        """
        Turns the robot's motor off.

        Returns:
            bool: True for test robot only, None otherwise.
        """
        if self.robot_type == "denso":
            self.action_object.motor_off()

        if self.robot_type == "test":
            sleep(1)
            print("Motor off Tac")
            return True

    # Move Joints/Cartesian methods
    @property
    def joints(self):
        return self.get_joints()

    def get_joints(self):
        """
        Retrieves the joint positions of the robot in radians.

        Returns:
            list[float]: A list of joint positions.
        """
        if self.robot_type == "denso":
            return self.action_object.get_joints()

        if self.robot_type == "test":
            sleep(0.5)
            return ["J1", "J2", "J3", "J4", "J5", "J6"]

    def move_joints(self, j1, j2, j3, j4, j5, j6):
        """
        Moves the robot's joints to the specified positions in degrees.

        Args:
            j1 (float): Joint 1 position.
            j2 (float): Joint 2 position.
            j3 (float): Joint 3 position.
            j4 (float): Joint 4 position.
            j5 (float): Joint 5 position.
            j6 (float): Joint 6 position.

        Returns:
            bool: True for test robot only, None otherwise.
        """
        if self.robot_type == "denso":
            self.action_object.move_joints(j1, j2, j3, j4, j5, j6)

        if self.robot_type == "test":
            sleep(1)
            return True

    @property
    def cartesian(self):
        return self.get_cartesian()

    def get_cartesian(self):
        """
        Retrieves the Cartesian pose of the end-effector as [x, y, z, roll, pitch, yaw].

        Returns:
            list[float]: A list containing position and orientation.
        """
        if self.robot_type == "denso":
            return self.action_object.get_cartesian()

        if self.robot_type == "test":
            sleep(1)
            return True

    def move_cartesian(self, x, y, z, roll, pitch, yaw):
        """
        Moves the end-effector to the specified Cartesian pose.

        Args:
            x (float): X-coordinate in meters.
            y (float): Y-coordinate in meters.
            z (float): Z-coordinate in meters.
            roll (float): Roll rotation in radians.
            pitch (float): Pitch rotation in radians.
            yaw (float): Yaw rotation in radians.

        Returns:
            bool: True for test robot only, None otherwise.
        """
        if self.robot_type == "denso":
            return self.action_object.move_cartesian([x, y, z, roll, pitch, yaw])

        if self.robot_type == "test":
            sleep(1)
            return True

    def move_to_home(self):
        """
        Moves the robot to its home position.

        Returns:
            bool: True for test robot only, None otherwise.
        """
        if self.robot_type == "denso":
            self.action_object.move_to_home()

        if self.robot_type == "test":
            sleep(1)
            return True

    def move_to_zero(self):
        """
        Moves the robot to the zero position.

        Returns:
            bool: True for test robot only, None otherwise.
        """
        if self.robot_type == "denso":
            self.action_object.move_to_zero()

        if self.robot_type == "test":
            sleep(1)
            return True

    def open_gripper(self):
        """
        Opens the robot's gripper.

        Returns:
            bool: True for test robot only, None otherwise.
        """
        if self.robot_type == "denso":
            self.action_object.open_gripper()

        if self.robot_type == "test":
            sleep(1)
            return True

    def close_gripper(self):
        """
        Closes the robot's gripper.

        Returns:
            bool: True for test robot only, None otherwise.
        """
        if self.robot_type == "denso":
            self.action_object.close_gripper()

        if self.robot_type == "test":
            sleep(1)
            return True

    def set_velocity(self, speed, acceleration=10, deceleration=10):
        """
        Sets the robot's maximum velocity.

        Args:
            speed (float): Speed percentage (1 to 100).
            acceleration (float, optional): Acceleration percentage. Default to 10.
            deceleration (float, optional): Deceleration percentage. Default to 10.

        Returns:
            bool: True for test robot only, None otherwise.
        """
        if self.robot_type == "denso":
            self.action_object.set_velocity(speed, acceleration, deceleration)

        if self.robot_type == "test":
            sleep(1)
            return True

    def calibrate(self):
        """
        Start an automatic motors calibration if motors are not calibrated yet

        *NOT IMPLEMENTED*

        """
        if self.robot_type == "denso":
            ...

        if self.robot_type == "test":
            sleep(1)
            return True

    def go_to_sleep(self):
        """
        Go home pose and activate learning mode. The function is available only for Ned robot.

        *NOT IMPLEMENTED*

        """
        if self.robot_type == "denso":
            ...

        if self.robot_type == "test":
            sleep(1)
            return True
