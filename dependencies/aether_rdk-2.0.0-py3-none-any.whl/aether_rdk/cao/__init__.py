import os
import subprocess

from aether_rdk.utils import install_check_denso_library

if install_check_denso_library():
    subprocess.run(
        ["python", "-m", "win32com.client.makepy", "low_level.CaoEngine"],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )

    from aether_rdk.cao.cao_engine import CAOEngineObject

elif os.environ.get("USING_ROBOT_TEST") is None:
    raise ImportError("ORiN2 SDK installation not found on your system")
else:
    CAOEngineObject = None

from aether_rdk.cao.cao_command_manager import CAOCommandManager
from aether_rdk.cao.cao_controller import CAOController
from aether_rdk.cao.cao_extension_manager import CAOExtensionManager
from aether_rdk.cao.cao_file_manager import CAOFileManager
from aether_rdk.cao.cao_message_manager import CAOMessageManager
from aether_rdk.cao.cao_robot_manager import CAORobotManager
from aether_rdk.cao.cao_task_manager import CAOTaskManager
from aether_rdk.cao.cao_variable_manager import CAOVariableManager
from aether_rdk.cao.cao_workspace import CAOWorkspace
from aether_rdk.cao.enumerates import (
    ControllerExecuteEnum,
    RobotExecuteEnum,
    TaskExecutionMode,
    TaskGetStatus,
    TaskSetThreadPriorityEnum,
    TaskStartMode,
    TaskStopMode,
)
