class CAOCommandManager:
    """
    This class contains methods for manipulate the CAOCommand object. CAOCommand is responsible for creating the
    CAOCommand object.

    From the CaoController object, it is possible to use all the other related methods.
    """

    def __init__(self, cao_command):
        self.cao_command = cao_command

    def execute(self, mode):
        """
        Execute the command.
        Args:
            mode: mode of execution
        """
        self.cao_command.Execute(mode)

    def cancel(self):
        """
        Cancel the command.
        """
        self.cao_command.Cancel()

    @property
    def timeout(self):
        """
        The Timeout property returns the timeout period of the command.
        Returns:
            CAOCommand Timeout: Timeout period
        """
        return self.cao_command.Timeout

    @timeout.setter
    def timeout(self, new_value):
        """
        The Timeout property sets the timeout period of the command.
        Args:
            new_value: new timeout period
        """
        self.cao_command.Timeout = new_value

    @property
    def state(self):
        """
        The State property returns the state of the command.
        Returns:
            CAOCommand State: State of the command
        """
        return self.cao_command.State

    @property
    def parameters(self):
        """
        The Parameters property returns the parameters of the command.
        Returns:
            CAOCommand Parameters: Parameters of the command
        """
        return self.cao_command.Parameters

    @parameters.setter
    def parameters(self, new_value):
        """
        The Parameters property sets the parameters of the command.
        Args:
            new_value: new parameters of the command
        """
        self.cao_command.Parameters = new_value

    @property
    def result(self):
        """
        The Result property returns the result of the command.
        Returns:
            CAOCommand Result: Result of the command
        """
        return self.cao_command.Result

    @property
    def attribute(self):
        """
        The Attribute property returns the attribute of the command.
        Returns:
            CAOCommand Attribute: Attribute of the command
        """
        return self.cao_command.Attribute

    @property
    def help(self):
        """
        The Help property returns the help of the command.
        Returns:
            CAOCommand Help: Help of the command
        """
        return self.cao_command.Help

    @property
    def name(self):
        """
        The Name property returns the name of the command.
        Returns:
            CAOCommand Name: Name of the command
        """
        return self.cao_command.Name

    @property
    def tag(self):
        """
        The Tag property returns the tag of the command.
        Returns:
            CAOCommand Tag: Tag of the command
        """
        return self.cao_command.Tag

    @tag.setter
    def tag(self, new_value):
        """
        The Tag property sets the tag of the command.
        Args:
            new_value: new tag of the command
        """
        self.cao_command.Tag = new_value

    @property
    def id(self):
        """
        The ID property returns the id of the command.
        Returns:
            CAOCommand ID: ID of the command
        """
        return self.cao_command.Id

    @id.setter
    def id(self, new_value):
        """
        The ID property sets the id of the command.
        Args:
            new_value: new id of the command
        """
        self.cao_command.Id = new_value

    @property
    def index(self):
        """
        The Index property returns the index of the command.
        Returns:
            CAOCommand Index: Index of the command
        """
        return self.cao_command.Index
