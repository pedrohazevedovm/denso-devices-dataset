import pythoncom
import win32api
from win32com import client


class CAOEngine:
    """
    A common function to the low_level provider and the low_level interface are offered to the client with the low_level engine by
    middleware (EXE) that mounts the interface of low_level. A common function to the low_level provider includes the collection
    function, the message output, and the CRD switch function, etc.
    """

    cao_engine = None

    def __init__(self):
        """
        Create a low_level engine object and store in the cao_engine variable.

        This object is used to access the low_level engine methods and is related to the dispatch object.

        For access the low_level engine object, use the cao_engine variable through the method get_dcom_dispatch.
        """

        self.cao_engine = client.Dispatch("cao.CaoEngine")

        self.__MAIN_THREAD_ID = win32api.GetCurrentThreadId()
        self.__dcom_git = self.create_dcom_git()
        self.__cookie = self.__dcom_git.RegisterInterfaceInGlobal(self.cao_engine._oleobj_, pythoncom.IID_IDispatch)

    def create_dcom_git(self):
        """
        Create a Global Interface Table object.

        Returns:
            IGlobalInterfaceTable: Global Interface Table object
        """
        # This approach is based in pywin32 multithreaded unit test available on
        # https://github.com/mhammond/pywin32/blob/main/com/win32com/test/testGIT.py
        pythoncom.CoInitialize()

        return pythoncom.CoCreateInstance(
            pythoncom.CLSID_StdGlobalInterfaceTable,
            None,
            pythoncom.CLSCTX_INPROC,
            pythoncom.IID_IGlobalInterfaceTable,
        )

    def get_dcom_dispatch(self):
        """
        Acquisition of a low_level engine object.

        Returns:
            CAOEngine: low_level engine object
        """
        if self.__MAIN_THREAD_ID != win32api.GetCurrentThreadId():
            my_git = self.create_dcom_git()

            cao_engine = my_git.GetInterfaceFromGlobal(self.__cookie, pythoncom.IID_IDispatch)
            return client.Dispatch(cao_engine)
        else:
            return self.cao_engine

    def workspace_remove(self, workspace_index):
        """
        Remove workspace from low_level engine.This method uses the Workspaces.Remove of the low_level engine method.
        Args:
            workspace_index:

        Returns:
            True if the workspace was removed, False otherwise.
        """
        engine_for_thread = self.get_dcom_dispatch()
        workspaces_prev_count = engine_for_thread.Workspaces.Count
        engine_for_thread.Workspaces.Remove(workspace_index)
        return workspaces_prev_count == engine_for_thread.Workspaces.Count + 1

    def release_root_dcom(self):
        """
        Release the low_level engine handlers (stop low_level.exe) and delete all related objects.
        """
        self.__dcom_git.RevokeInterfaceFromGlobal(self.__cookie)
        pythoncom.CoUninitialize()
        del self.cao_engine
        del self.__dcom_git

    def release_current_dcom(self):
        """
        Release the low_level engine handlers (stop low_level.exe) and delete all related objects.
        """
        pythoncom.CoUninitialize()
        engine_for_thread = self.get_dcom_dispatch()
        del engine_for_thread

    @property
    def engine_status(self):
        """
        Acquisition of an engine status object.

        Returns:
            CAOEngine Status: Engine status
        """
        engine_for_thread = self.get_dcom_dispatch()
        return engine_for_thread.EngineStatus

    @property
    def workspaces(self):
        """
         Acquisition of a workspace collection.

        Returns:
            CAOEngine Workspaces: Workspaces list
        """
        engine_for_thread = self.get_dcom_dispatch()
        return engine_for_thread.Workspaces

    @property
    def workspaces_names(self):
        """
        Get the workspaces' names from the CAOEngine object.

        Returns:
            a list with the workspaces' names
        """
        len_workspaces = self.cao_engine.Workspaces.Count

        names = []
        for i in range(len_workspaces):
            names.append(self.cao_engine.Workspaces.Item(i).Name)

        return names


# CAOEngine Singleton instance, wrapper for a DCOM object
CAOEngineObject = CAOEngine()
