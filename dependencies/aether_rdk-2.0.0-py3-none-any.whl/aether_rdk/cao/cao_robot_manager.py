from aether_rdk.cao.cao_variable_manager import CAOVariableManager
from aether_rdk.cao.executes.robot_execute import RobotExecute


class CAORobotManager:
    """
    This class is a wrapper for the CAORobot object. This class contains methods for manipulate the CAORobot object.
    CAORobot is responsible for creating the CAORobot object.

    From the CaoController object, it is possible to use all the other related methods.
    """

    def __init__(self, cao_robot):
        self.cao_robot = cao_robot
        self.robot_execute = RobotExecute(self.cao_robot)

    def add_variable(self, name, option=""):
        """
        Add a variable to the robot.

        Args:
            name: string,
            option: string,
        Returns:
            CAORobot AddVariable: CAOVariable object
        """
        cao_variable_dispatch = self.cao_robot.AddVariable(name, option)
        cao_variable = CAOVariableManager(cao_variable_dispatch, name)

        return cao_variable

    @property
    def variable_names(self):
        """
        The VariableNames property returns the variables names of the robot.

        Returns:
            CAORobot VariableNames: variable names of the robot
        """
        return self.cao_robot.VariableNames

    def execute(self, command, param=None):
        """
        Execute a command.

        Args:
            command: string,
            param: string,
        Returns:
            CAORobot Execute: return of the command
        """
        return self.robot_execute.execute(command, param)

    def accelerate(self, axis, accel, deceleration):
        """
        Set the acceleration and deceleration of the robot.

        Args:
            axis: specifies the axis to be set
            accel: acceleration
            deceleration: deceleration
        """
        self.cao_robot.Accelerate(axis, accel, deceleration)

    def change(self, name):
        """
        This method corresponds to CHANGETOOL and CHANGEWORK instructions of PacScript language.

        Args:
            name: string,
        """
        self.cao_robot.Change(name)

    def chuck(self, option=""):
        """
        This method corresponds to CHUCK instruction of PacScript language.

        DCOM say: The function is not mounted.

        Args:
            option: string,
        """
        raise NotImplementedError("The function is not mounted.")

    def drive(self, axis, mov, option=""):
        """
        This method is not supported directly in this provider.
        Instead, use "DriveEx" or "DriveAEx" command of CaoRobot::Execute that can operate two or more axes all at once.
        """
        raise NotImplementedError("This method is not supported directly in this provider")

    def go_home(self):
        """
        This method sends move to home command to robot.

        DCOM say: The function is not mounted.

        """
        raise NotImplementedError("This method is not supported directly in this provider")

    def halt(self, option=""):
        """
        Stop the robot motion.
        A runtime error occurs if a task in the RC8 controller has robot control authority (when Takearm has been
        executed).

        Use the CaoTask::Stop method to control the stop of a task.

        Args:
            option: string,

        Returns:
            CAORobot Halt: return of the command
        """
        return self.cao_robot.Halt(option)

    def hold(self, option=""):
        """
        This method corresponds to HOLD instruction of PacScript language.

        DCOM say: The function is not mounted.

        Args:
            option: string,

        Returns:
            CAORobot Hold: return of the command
        """
        raise NotImplementedError("The function is not mounted.")

    def move(self, comp, pose, option=""):
        """
        Move the robot to the specified coordinates. This method corresponds to MOVE instruction of PacScript language.
        The following shows the argument specifications of Move.

        Args:
            comp: specifies the interpolation method to be used for the movement,
            pose: pose data,
            option: motion option,
        """
        self.cao_robot.Move(comp, pose, option)

    def rotate(self, rotate_surface, deg, pivot, option=""):
        """
        Rotate the robot around the specified axis. This method corresponds to ROTATE instruction of PacScript language.

        Args:
            rotate_surface: specifies the surface to be rotated,
            deg: specifies the rotation angle,
            pivot: specifies the rotation center,
            option: motion option,
        """
        self.cao_robot.Rotate(rotate_surface, deg, pivot, option)

    def speed(self, axis, speed):
        """
        Set the internal movement speed of the robot. Actual speed is calculated by multiplying the external speed by
        the internal speed.
        About the external movement speed of the robot, use "ExtSpeed" command of cao_robot.execute.

        Args:
            axis: -1: Effective to Tool axis (SPEED),
                   0: Effective to all axes (JSPEED)
            speed: speed
        """
        self.cao_robot.Speed(axis, speed)

    def unchuck(self, option=""):
        """
        This method corresponds to UNCHUCK instruction of PacScript language.

        DCOM say: The function is not mounted.

        Args:
            option: string,
        """
        raise NotImplementedError("The function is not mounted.")

    def unhold(self, option=""):
        """
        This method corresponds to UNHOLD instruction of PacScript language.

        DCOM say: The function is not mounted.

        Args:
            option: string,
        """
        raise NotImplementedError("The function is not mounted.")

    @property
    def attribute(self):
        """
        The Attribute property returns the attribute of the robot.

        DCOM say: The function is not mounted.

        Returns:
            CAORobot Attribute: attribute of the robot
        """
        raise NotImplementedError("The function is not mounted.")

    @property
    def help(self):
        """
        The Help property returns the help of the robot.

        DCOM say: The function is not mounted.

        Returns:
            CAORobot Help: help of the robot
        """
        raise NotImplementedError("The function is not mounted.")

    @property
    def name(self):
        """
        The Name property returns the name of the robot.

        Returns:
            CAORobot Name: name of the robot
        """
        return self.cao_robot.Name

    @property
    def tag(self):
        """
        The Tag property returns the tag of the robot.

        Returns:
            CAORobot Tag: tag of the robot
        """
        return self.cao_robot.Tag

    @tag.setter
    def tag(self, new_value):
        """
        The Tag property sets the tag of the robot.

        Args:
            new_value: new tag of the robot
        """
        self.cao_robot.Tag = new_value

    @property
    def id(self):
        """
        The ID property returns the id of the robot.

        Returns:
            CAORobot ID: ID of the robot
        """
        return self.cao_robot.ID

    @id.setter
    def id(self, new_value):
        """
        The ID property sets the id of the robot.

        THIS METHOD IS NOT WORKING!

        AttributeError: Property 'AddRobot.ID' cannot be set.

        Args:
            new_value: new id of the robot
        """
        raise NotImplementedError("Property 'AddRobot.ID' cannot be set.")

    @property
    def index(self):
        """
        The Index property returns the index of the robot.

        Returns:
            CAORobot Index: index of the robot
        """
        return self.cao_robot.Index

    @property
    def variables(self):
        """
        The Variables property returns the variables of the robot.

        Returns:
            CAORobot Variables: variables of the robot
        """
        return self.cao_robot.Variables
