from aether_rdk.utils import MetaSingleton
from aether_rdk.cao.cao_variable_manager import CAOVariableManager


class CAOTaskManager(metaclass=MetaSingleton):
    """
    This class contains methods for manipulate the CAOTask object. CAOTask is responsible for creating the CAOTask
    object.

    From the CaoController object, it is possible to use all the other related methods.

    The AddTask argument method of the CaoController class specifies the task name (BSTR type).

    "Task name" specified here specifies a PAC program name. For instance, the CaoTask object is retrieved in the
    expression like AddTask("pro1").

    """

    def __init__(self, cao_task, task_name):
        self.cao_task = cao_task
        self.task_name = task_name

    def add_variable(self, name, option=""):
        """
        The AddVariable method creates a new CAOVariable object from manipulate a variable.
        Args:
            name: string,
            option: string,

        Returns:
            CAOVariable: CAOVariable object
        """
        cao_variable_dispatch = self.cao_task.AddVariable(name, option)
        cao_variable = CAOVariableManager(cao_variable_dispatch, name)

        return cao_variable

    @property
    def variable_names(self):
        """
        The VariableNames property returns a collection names of the variables that are registered in the controller.
        Returns:
            CAOFile VariableNames: Variables list
        """
        return self.cao_task.VariableNames

    def execute(self, command, param=None):
        """
        The Execute method executes the specified command in the controller.
        Args:
            command: string,
            param: string,
        """
        return self.cao_task.Execute(command, param)

    def start(self, mode, option=""):
        """
        The Start method starts the task. Run the PAC program that supports the object.

        Start mode 1: One cycle execution, 2: Continuous execution, 3: Step forward

        Args:
            mode: int,
            option: string,
        """
        self.cao_task.Start(mode, option)

    def stop(self, mode, option=""):
        """
        The Stop method stops the task. Stop the PAC program that supports the object.

        Stop mode 0: Default stop, 1: Instant stop, 2: Step stop, 3: Cycle stop, 4: Initialized stop

        Args:
            mode: int,
            option: string,
        """
        self.cao_task.Stop(mode, option)

    def delete(self, option=""):
        """
        The Delete method deletes the task. Delete the PAC program that supports the object.

        DCOM say: The function is not mounted.

        Args:
            option: string,
        """
        raise NotImplementedError("The function is not mounted.")

    @property
    def file_name(self):
        """
        The FileName property returns the name of the file, include the path, that is registered in the controller.

        Returns:
            CAOFile FileName: File name
        """
        return self.cao_task.FileName

    @property
    def attribute(self):
        """
        The Attribute property returns the attribute of the task.

        DCOM say: The function is not mounted.

        Returns:
            CAOFile Attribute: Attribute
        """
        raise NotImplementedError("The function is not mounted.")

    @property
    def help(self):
        """
        The Help property returns the help of the task.

        DCOM say: The function is not mounted.

        Returns:
            CAOFile Help: Help
        """
        raise NotImplementedError("The function is not mounted.")

    @property
    def name(self):
        """
        The Name property returns the name of the task.

        Returns:
            CAOFile Name: Name
        """
        return self.cao_task.Name

    @property
    def tag(self):
        """
        The Tag property returns the tag of the task.
        Returns:
            CAOFile Tag: Tag
        """
        return self.cao_task.Tag

    @tag.setter
    def tag(self, new_value):
        """
        The Tag property sets the tag of the task.
        Args:
            new_value: new tag value
        """
        self.cao_task.Tag = new_value

    @property
    def id(self):
        """
        The ID property returns the ID of the task.
        Returns:
            CAOFile ID: ID
        """
        return self.cao_task.ID

    @id.setter
    def id(self, new_value):
        """
        The ID property sets the ID of the task.

        THIS METHOD IS NOT WORKING!

        Args:
            new_value: new ID value
        """
        raise NotImplementedError("Property 'AddTask.ID' cannot be set.")


    @property
    def index(self):
        """
        The Index property returns the index of the task.
        Returns:
            CAOFile Index: Index
        """
        return self.cao_task.Index

    @property
    def variables(self):
        """
        The Variables property returns a collection of the variables that are registered in the controller.
        Returns:
            CAOFile Variables: Variables list
        """
        return self.cao_task.Variables
