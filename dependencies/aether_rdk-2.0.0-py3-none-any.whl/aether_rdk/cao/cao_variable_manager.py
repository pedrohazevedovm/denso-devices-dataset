from aether_rdk.utils import MetaSingleton


class CAOVariableManager(metaclass=MetaSingleton):
    """
    This class contains methods for manipulate the CAOVariable object. CAOVariable is responsible for creating the
    CAOVariable object.

    From the CaoController object, it is possible to use all the other related methods.

    The AddVariable method of this CaoController class is a method for access to the variable. In the RC8 provider,
    both the user variable and the system variable can be specified for the variable name.

    User variables support the following variables, i.e., RC8 controller global variables (I, F, V, P, J, D, T, S) and
    I/O.
    """

    def __init__(self, cao_variable, variable_name):
        self.cao_variable = cao_variable
        self.variable_name = variable_name

    @property
    def datetime(self):
        """
        The DateTime property returns the date and time when the variable was last updated.

        Returns:
            CAOFile DateTime: Datetime
        """
        return self.cao_variable.DateTime

    @property
    def value(self):
        """
        The Value property returns the value of the variable.

        Returns:
            CAOFile Value: Value
        """
        return self.cao_variable.Value
    @value.setter
    def value(self, new_value):
        """
        The Value property sets the value of the variable.

        Args:
            new_value: new value
        """
        self.cao_variable.Value = new_value

    @property
    def attribute(self):
        """
        The Attribute property returns the attribute of the variable.

        DCOM say: There was access that had not been permitted.
                  Please confirm the access condition.

        Returns:
            CAOFile Attribute: Attribute
        """
        raise NotImplementedError("There was access that had not been permitted. Please confirm the access condition.")

    @property
    def help(self):
        """
        The Help property returns the help of the variable.

        DCOM say: The function is not mounted.

        Returns:
            CAOFile Help: Help
        """
        raise NotImplementedError("The function is not mounted.")

    @property
    def name(self):
        """
        The Name property returns the name of the variable.

        Returns:
            CAOFile Name: Name
        """
        return self.cao_variable.Name

    @property
    def tag(self):
        """
        The Tag property returns the tag of the variable.

        Returns:
            CAOFile Tag: Tag
        """
        return self.cao_variable.Tag

    @tag.setter
    def tag(self, new_value):
        """
        The Tag property sets the tag of the variable.

        Args:
            new_value: new tag value
        """
        self.cao_variable.Tag = new_value

    @property
    def id(self):
        """
        The ID property returns the ID of the variable.

        Returns:
            CAOFile ID: ID
        """
        return self.cao_variable.ID

    @id.setter
    def id(self, new_value):
        """
        The ID property sets the ID of the variable.

        THIS METHOD IS NOT WORKING!

        """
        raise NotImplementedError("Property 'AddTask.ID' cannot be set.")

    @property
    def microsecond(self):
        """
        The Microsecond property returns the microsecond of the variable.

        Returns:
            CAOFile Microsecond: Microsecond
        """
        return self.cao_variable.Microsecond

    @property
    def index(self):
        """
        The Index property returns the index of the variable.

        Returns:
            CAOFile Index: Index
        """
        return self.cao_variable.Index
