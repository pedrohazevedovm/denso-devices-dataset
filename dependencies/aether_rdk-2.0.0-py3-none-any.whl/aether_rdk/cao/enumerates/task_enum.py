from enum import Enum, IntEnum


class TaskExecutionMode(Enum):
    """Enum for Task execution"""

    GetStatus = 1
    GetThreadPriority = 2
    SetThreadPriority = 3

    def __str__(self) -> str:
        full_name = super().__str__()
        scope_name = full_name.split(".")[-1]
        return scope_name


class TaskGetStatus(Enum):
    """Enum for Task status"""

    TASK_NON_EXISTENT = 0
    TASK_SUSPEND = 1
    TASK_READY = 2
    TASK_RUN = 3
    TASK_STEPSTOP = 4

    def __str__(self) -> str:
        full_name = super().__str__()
        scope_name = full_name.split(".")[-1]
        return scope_name


class TaskSetThreadPriorityEnum(Enum):
    """Enum for Task thread priority"""

    THREAD_PRIORITY_HIGHEST = 2
    THREAD_PRIORITY_ABOVE_NORMAL = 1
    THREAD_PRIORITY_NORMAL = 0
    THREAD_PRIORITY_BELOW_NORMAL = -1
    THREAD_PRIORITY_LOWEST = -2

    def __str__(self) -> str:
        full_name = super().__str__()
        scope_name = full_name.split(".")[-1]
        return scope_name


class TaskStartMode(IntEnum):
    """Enum for Task start mode"""

    ONE_CYCLE_EXECUTION = 1
    CONTINUOUS_EXECUTION = 2
    STEP_FORWARD = 3

    def __str__(self) -> str:
        full_name = super().__str__()
        scope_name = full_name.split(".")[-1]
        return scope_name


class TaskStopMode(IntEnum):
    """Enum for Task stop mode"""

    DEFAULT_STOP = 0
    INSTANT_STOP = 1
    STEP_STOP = 2
    CYCLE_STOP = 3
    INITIALIZED_STOP = 4

    def __str__(self) -> str:
        full_name = super().__str__()
        scope_name = full_name.split(".")[-1]
        return scope_name
