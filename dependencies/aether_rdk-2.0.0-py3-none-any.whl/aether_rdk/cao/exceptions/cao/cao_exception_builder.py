from aether_rdk.cao.exceptions.cao.cao_exceptions_table import (
    CAO_ENGINE_ERRORS,
    CAO_PROVIDER_ERRORS,
)
from aether_rdk.cao.exceptions.cao.cao_exceptions_types import (
    CAOEngineError,
    CAOProviderError,
    ControllerError,
)
from aether_rdk.cao.exceptions.cao.cao_parser_errors_csv import (
    create_errors_database,
    search_error_details,
)
from aether_rdk.cao.exceptions.dcom import DCOM_COMMON_ERRORS, DComCommonError
from aether_rdk.utils import dec_complemented2_to_hex


class ControllerExceptionBuilder:
    def __new__(cls, raw_error_code) -> ControllerError | CAOEngineError | CAOProviderError | Exception:
        hex_error_code = dec_complemented2_to_hex(raw_error_code, 32)
        error_details = search_error_details(create_errors_database(), hex_error_code)

        if error_details is not None:
            return ControllerError(hex_error_code, error_details)

        if hex_error_code in CAO_ENGINE_ERRORS.keys():
            return CAOEngineError(hex_error_code, CAO_ENGINE_ERRORS)

        if hex_error_code in CAO_PROVIDER_ERRORS.keys():
            return CAOProviderError(hex_error_code, CAO_PROVIDER_ERRORS)

        # TODO: See a better way to handle this case, from not mix DComExceptionBuilder with ControllerExceptionBuilder
        if hex_error_code in DCOM_COMMON_ERRORS.keys():
            return DComCommonError(hex_error_code, DCOM_COMMON_ERRORS)

        return Exception("unknown error code to denso controller:", hex_error_code)
