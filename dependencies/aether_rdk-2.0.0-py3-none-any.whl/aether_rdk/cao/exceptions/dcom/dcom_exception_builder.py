from aether_rdk.cao.exceptions.dcom.dcom_exceptions_table import DCOM_COMMON_ERRORS
from aether_rdk.cao.exceptions.dcom.dcom_exceptions_types import DComCommonError
from aether_rdk.utils import dec_complemented2_to_hex


class DComExceptionBuilder:
    def __new__(cls, raw_error_code) -> DComCommonError | Exception:
        hex_error_code = dec_complemented2_to_hex(raw_error_code, 32)
        if hex_error_code in DCOM_COMMON_ERRORS.keys():
            return DComCommonError(hex_error_code, DCOM_COMMON_ERRORS)

        return Exception("unknown DCom error code:", hex_error_code)
