from aether_rdk.cao.exceptions.cao import ControllerExceptionBuilder
from aether_rdk.cao.exceptions.dcom import DComExceptionBuilder


class DensoExceptionHandler(Exception):
    def __init__(self, error_tuple):
        try:
            if len(error_tuple) == 1:
                error_tuple = error_tuple[0]

            if not isinstance(error_tuple[2], int):
                comm_error_code = error_tuple[0]
                controller_error_code = error_tuple[2][5]
                self.__communication = DComExceptionBuilder(comm_error_code)
                self.__controller = ControllerExceptionBuilder(controller_error_code)

            # This is necessary when the controller_current_error is triggered, beacuse the response dont have a
            # DcomExeceptionBuilder just Controller ExceptionBuilder
            else:
                comm_error_code = error_tuple[0]
                controller_error_code = error_tuple[2]

                self.__communication = None
                self.__controller = ControllerExceptionBuilder(controller_error_code)

        except Exception as e:

            raise Exception(f"{e} Unknown error code to denso controller: {error_tuple}")

    @property
    def controller_error(self):
        return self.__controller

    @property
    def dcom_error(self):
        return self.__communication

    def __str__(self):
        if self.__communication:
            return f"{self.__communication}\n{self.__controller}"

        else:
            return f"{self.__controller}"
