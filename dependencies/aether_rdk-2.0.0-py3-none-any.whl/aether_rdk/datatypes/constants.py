"""
This module contains all enums used in the system.
"""

from enum import Enum, auto

TOLERANCE = 1e-4


class DataType(Enum):
    """
    Type JOINT: Data type joint.
    Type POSE: Data type pose.
    Type HOMOGENEOUS_TRANSLATION: Data type homogeneous translation.
    Type DENSO_HOMOGENEOUS_TRANSLATION: Data type denso homogeneous translation.
    Type VECTOR: Data type vector.
    """

    JOINT = auto()
    POSE = auto()
    HOMOGENEOUS_TRANSLATION = auto()
    DENSO_HOMOGENEOUS_TRANSLATION = auto()
    VECTOR = auto()
    OFFSET = auto()


# flake8: noqa: E741


class CAOVariableType(Enum):
    """
    Type I: Integer variable (range: -2147483648 to + 2147483647)
    Type F: Floating-point variable of type real (-3.402823E+38 to 3.402823E+38)
    Type D: Double-precision variable of type real (-1.79769313486231D+308 to 1.79769313486231D+308)
    Type S: String variable (maximum of 243 characters)
    Type V: Vector variable (X, Y, Z)
    Type P: Position variable (X, Y, Z, RX, RY, RZ, FIG)
    Type T: Homogeneous transform variable (X, Y, Z, Ox, Oy, Oz, Ax, Ay, Az, FIG)
    Type J: Joint variable (J1, J2, J3, J4, J5, J6) (6 axes) (J1,J2,J3,J4) (4 axes)
    Type IO: Signal I/O variable
    """

    I = auto()
    F = auto()
    D = auto()
    S = auto()
    V = auto()
    P = auto()
    T = auto()
    J = auto()
    IO = auto()

    def __str__(self) -> str:
        full_name = super().__str__()
        scope_name = full_name.split(".")[-1]
        return scope_name


class CAOReferenceType(Enum):
    """
    Type TOOL: Tool variable in Offset3D
    Type WORK: Work variable in Offset3D
    Type AREA: Area variable in Area3D
    Type PATH_POINT: Point variable
    """

    # TODO put the others References Types if can by change with CAO
    TOOL = auto()
    WORK = auto()
    AREA = auto()
    PATH_POINT = auto()

    def __str__(self) -> str:
        full_name = super().__str__()
        scope_name = full_name.split(".")[-1]
        return scope_name


class TaskExecutionMode(Enum):
    """
    Type ONE_CYCLE_EXECUTION: Task execution mode for one cycle.
    Type CONTINUOUS_EXECUTION: Task execution mode for continuous cycle.
    Type STEP_FORWARD: Task execution mode for forward cycle.
    """

    ONE_CYCLE_EXECUTION = auto()
    CONTINUOUS_EXECUTION = auto()
    STEP_FORWARD = auto()


class DensoCommunicationStatus(Enum):
    """
    Type OPENED: Denso communication status if is open.
    Type CLOSED: Denso communication status if is closed.
    Type CONNECT: Denso communication status if is connected.
    """

    OPENED = auto()
    CLOSED = auto()
    CONNECT = auto()


class CartesianAxis(Enum):
    """
    Type X: Type of cartesian axis X.
    Type Y: Type of cartesian axis Y.
    Type Z: Type of cartesian axis Z.
    """

    X = auto()
    Y = auto()
    Z = auto()
