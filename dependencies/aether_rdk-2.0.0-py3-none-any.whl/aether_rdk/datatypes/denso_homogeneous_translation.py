from math import isclose
from dataclasses import asdict, dataclass

from aether_rdk.datatypes.constants import DataType, TOLERANCE


@dataclass
class DensoHomogeneousTranslation:
    """
    This class is a data class that represents a denso robot homogeneous translation matrix object.
    In denso user manual, the homogeneous translation matrix is represented by:
    [X, Y, Z, Ox, Oy, Oz, Ax, Ay, Az, FIG]

    X, Y, Z: Position of the origin of the coordinate system
    Ox, Oy, Oz: Elements of the orient vector
    Ax, Ay, Az: Elements of the approach vector
    FIG: Component representing the Robot Figure

    This content is available in the user manual, in page: RC8UserManuals_2201_en/en/000458.html

    This representation is called 2-vector representation for rotation matrix in 3d.
    In this link, you can find more information about the homogeneous translation matrix:
    https://robotacademy.net.au/lesson/2-vector-representation-of-rotation-in-3d/
    """

    data_type: DataType = DataType.DENSO_HOMOGENEOUS_TRANSLATION
    x: float = 0
    y: float = 0
    z: float = 0
    ox: float = 0
    oy: float = 0
    oz: float = 0
    ax: float = 0
    ay: float = 0
    az: float = 0
    fig: int = 0

    # parse to or from
    def __init__(self, x, y, z, ox, oy, oz, ax, ay, az, fig):
        DensoHomogeneousTranslation.__validate_types(x, y, z, ox, oy, oz, ax, ay, az, fig)
        self.x = x
        self.y = y
        self.z = z
        self.ox = ox
        self.oy = oy
        self.oz = oz
        self.ax = ax
        self.ay = ay
        self.az = az
        self.fig = fig

    # built-in operators
    def __str__(self):
        return (f"T({self.x}, {self.y}, {self.z}, "
                f"{self.ox}, {self.oy}, {self.oz}, "
                f"{self.ax}, {self.ay}, {self.az}, "
                f"{self.fig})")

    def __iter__(self):
        return iter(asdict(self).items())

    def __eq__(self, other):
        current = self.to_list()
        return all([True if isclose(current[n], other[n], abs_tol=TOLERANCE) else False for n in range(len(current))])

    def __len__(self):
        return len(self.to_list())

    def __getitem__(self, key):
        return getattr(self, key)

    def __setitem__(self, key, value):
        setattr(self, key, value)

    # Utils
    @staticmethod
    def __validate_types(x, y, z, ox, oy, oz, ax, ay, az, fig):
        """
        This method validates the types of the parameters passed to the class constructor.

        Args:
            x: the x value
            y: the y value
            z: the z value
            ox: the ox value
            oy: the oy value
            oz: the oz value
            ax: the ax value
            ay: the ay value
            az: the az value
            fig: the fig value
        """
        axis_values = [x, y, z, ox, oy, oz, ax, ay, az, fig]

        for val in axis_values:
            if not isinstance(val, float) and not isinstance(val, int):
                raise ValueError("Expected type float or int for axis, but was received:", type(val))

        if not isinstance(fig, int):
            raise ValueError("Expected type int for figure, but was received:", type(fig))

    @staticmethod
    def from_dict(data_dict):
        """
        This method creates a DensoHomogeneousTranslation object from a dictionary.

        Args:
            data_dict: the dictionary containing the data to be converted

        Returns:
            A DensoHomogeneousTranslation object.
        """
        return DensoHomogeneousTranslation(**data_dict)

    @staticmethod
    def from_list(data_list):
        """
        This method creates a DensoHomogeneousTranslation object from a list.

        Args:
            data_list: the list containing the data to be converted

        Returns:
            A DensoHomogeneousTranslation
        """
        return DensoHomogeneousTranslation(*data_list)

    def to_list(self):
        """
        This method converts the object to a list.

        Returns:
            A list containing the object's data.
        """
        return [self.x, self.y, self.z, self.ox, self.oy, self.oz, self.ax, self.ay, self.az, self.fig]
