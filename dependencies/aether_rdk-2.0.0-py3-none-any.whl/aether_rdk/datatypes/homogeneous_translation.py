import numpy as np

from math import isclose
from dataclasses import asdict, dataclass

from aether_rdk.datatypes.constants import DataType, TOLERANCE
from aether_rdk.datatypes.denso_homogeneous_translation import DensoHomogeneousTranslation


@dataclass
class HomogeneousTranslation:
    """
    This class is a data class that represents a robot homogeneous translation matrix object.
    The homogeneous translation matrix is represented by:
    [X, Y, Z, Nx, Ny, Nz, Ox, Oy, Oz, Ax, Ay, Az, FIG]

    X, Y, Z: Position of the origin of the coordinate system
    Nx, Ny, Nz: Elements of the normal vector
    Ox, Oy, Oz: Elements of the orient vector
    Ax, Ay, Az: Elements of the approach vector
    FIG: Component representing the Robot Figure

    This matrix corresponds to the transformation matrix of the robot, and is used to represent the robot's position
    and orientation in the workspace.

    X, Y, Z: Represent the translation of the robot in the workspace.
    Nx, Ny, Nz: Represent first column of the rotation matrix.
    Ox, Oy, Oz: Represent second column of the rotation matrix.
    Ax, Ay, Az: Represent third column of the rotation matrix.

    For mount the homogeneous transformation matrix, you can use the following code:
    homogeneous_translation = np.array([
        [Nx, Ox, Ax, X],
        [Ny, Oy, Ay, Y],
        [Nz, Oz, Az, Z],
        [0, 0, 0, 1]
    ])

    """

    data_type: DataType = DataType.HOMOGENEOUS_TRANSLATION
    x: float = 0
    y: float = 0
    z: float = 0
    nx: float = 0
    ny: float = 0
    nz: float = 0
    ox: float = 0
    oy: float = 0
    oz: float = 0
    ax: float = 0
    ay: float = 0
    az: float = 0
    fig: int = -1 # TODO: Testar se o valor -1 é valido

    # parse to or from
    def __init__(self, x, y, z, nx, ny, nz, ox, oy, oz, ax, ay, az, fig=-1):
        HomogeneousTranslation.__validate_types(x, y, z, nx, ny, nz, ox, oy, oz, ax, ay, az, fig)
        self.x = x
        self.y = y
        self.z = z
        self.nx = nx
        self.ny = ny
        self.nz = nz
        self.ox = ox
        self.oy = oy
        self.oz = oz
        self.ax = ax
        self.ay = ay
        self.az = az
        self.fig = fig

    # built-in operators
    def __str__(self):
        return (f"HT({self.x}, {self.y}, {self.z}, "
                f"{self.nx}, {self.ny}, {self.nz}, "
                f"{self.ox}, {self.oy}, {self.oz}, "
                f"{self.ax}, {self.ay}, {self.az}, "
                f"{self.fig})")

    def __iter__(self):
        return iter(asdict(self).items())

    # TODO: Preciso ver quais operações essa classe suportara
    def __eq__(self, other):
        current = self.to_list()
        return all([True if isclose(current[n], other[n], abs_tol=TOLERANCE) else False for n in range(len(current))])

    def __len__(self):
        return len(self.to_list())

    def __getitem__(self, key):
        return getattr(self, key)

    def __setitem__(self, key, value):
        setattr(self, key, value)

    # Utils
    @staticmethod
    def __validate_types(x, y, z, nx, ny, nz, ox, oy, oz, ax, ay, az, fig):
        """
        Validate the types of the HomogeneousTranslation object.

        Args:
            x: the x value
            y: the y value
            z: the z value
            nx: the nx value
            ny: the ny value
            nz: the nz value
            ox: the ox value
            oy: the oy value
            oz: the oz value
            ax: the ax value
            ay: the ay value
            az: the az value
            fig: the fig value
        """
        axis_values = [x, y, z, nx, ny, nz, ox, oy, oz, ax, ay, az, fig]

        for val in axis_values:
            if not isinstance(val, float) and not isinstance(val, int):
                raise ValueError("Expected type float or int for axis, but was received:", type(val))

        if not isinstance(fig, int):
            raise ValueError("Expected type int for figure, but was received:", type(fig))

    @staticmethod
    def from_dict(data_dict):
        """
        Convert a dictionary to a HomogeneousTranslation object

        Args:
            data_dict: the dictionary to be converted

        Returns:
            HomogeneousTranslation: A HomogeneousTranslation object.
        """
        return HomogeneousTranslation(**data_dict)

    @staticmethod
    def from_list(data_list):
        """
        Convert a list to a HomogeneousTranslation object.

        Args:
            data_list: the list to be converted

        Returns:
            HomogeneousTranslation: A HomogeneousTranslation object.
        """
        return HomogeneousTranslation(*data_list)

    def to_list(self):
        """
        Convert the HomogeneousTranslation object to a list.

        Returns:
            list: A list contains the HomogeneousTranslation values.
        """
        return [self.x, self.y, self.z,
                self.nx, self.ny, self.nz,
                self.ox, self.oy, self.oz,
                self.ax, self.ay, self.az,
                self.fig]

    def to_np_array(self):
        """
        Convert the HomogeneousTranslation object to a numpy array.

        Returns:
            np.array: A numpy array representing the HomogeneousTranslation object.
        """
        homogeneous_translation = np.array([
            [self.nx, self.ny, self.nz, self.x],
            [self.ox, self.oy, self.oz, self.y],
            [self.ax, self.ay, self.az, self.z],
            [      0,       0,       0,      1]
        ])

        return homogeneous_translation

    @staticmethod
    def from_np_array(homogeneous_translation: np.array):
        """
        Convert a numpy array to a HomogeneousTranslation object.

        Args:
            homogeneous_translation: A numpy array representing a homogeneous translation matrix.

        Returns:
            HomogeneousTranslation: A HomogeneousTranslation
        """
        nx = homogeneous_translation[0, 0]
        ny = homogeneous_translation[0, 1]
        nz = homogeneous_translation[0, 2]
        ox = homogeneous_translation[1, 0]
        oy = homogeneous_translation[1, 1]
        oz = homogeneous_translation[1, 2]
        ax = homogeneous_translation[2, 0]
        ay = homogeneous_translation[2, 1]
        az = homogeneous_translation[2, 2]
        x = homogeneous_translation[0, 3]
        y = homogeneous_translation[1, 3]
        z = homogeneous_translation[2, 3]

        return HomogeneousTranslation(x, y, z, nx, ny, nz, ox, oy, oz, ax, ay, az)

    def to_dht(self) -> DensoHomogeneousTranslation:
        """
        Convert the homogeneous translation matrix to a Denso homogeneous translation matrix.

        Returns:
            DensoHomogeneousTranslation: A Denso homogeneous translation matrix.
        """
        denso_homogeneous_translation = DensoHomogeneousTranslation(float(self.x), float(self.y), float(self.z),
                                                                    float(self.ox), float(self.oy), float(self.oz),
                                                                    float(self.ax), float(self.ay), float(self.az),
                                                                    int(self.fig))

        return denso_homogeneous_translation

    @staticmethod
    def from_dht(dht: DensoHomogeneousTranslation):
        """
        Convert a Denso homogeneous translation matrix to a homogeneous translation matrix.

        Args:
            dht: A Denso homogeneous translation matrix.

        Returns:
            HomogeneousTranslation: A HomogeneousTranslation
        """
        orientation_vector = np.array([dht.ox, dht.oy, dht.oz])
        approach_vector = np.array([dht.ax, dht.ay, dht.az])
        normal_vector = np.cross(orientation_vector, approach_vector)

        x = dht.x
        y = dht.y
        z = dht.z
        nx = float(normal_vector[0])
        ny = float(normal_vector[1])
        nz = float(normal_vector[2])
        ox = dht.ox
        oy = dht.oy
        oz = dht.oz
        ax = dht.ax
        ay = dht.ay
        az = dht.az
        fig = dht.fig

        return HomogeneousTranslation(x, y, z, nx, ny, nz, ox, oy, oz, ax, ay, az, fig)
