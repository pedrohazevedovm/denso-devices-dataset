from dataclasses import asdict, dataclass

from aether_rdk.datatypes.constants import DataType


@dataclass
class Joint:
    """
    This class is a data class that represents a robot joint command.
    """

    data_type: DataType = DataType.JOINT
    joint_1: float = 0
    joint_2: float = 0
    joint_3: float = 0
    joint_4: float = 0
    joint_5: float = 0
    joint_6: float = 0

    # parse to or from
    def __init__(self, j1, j2, j3, j4, j5, j6):
        Joint.__validate_types(j1, j2, j3, j4, j5, j6)
        self.joint_1 = j1
        self.joint_2 = j2
        self.joint_3 = j3
        self.joint_4 = j4
        self.joint_5 = j5
        self.joint_6 = j6

    # built-in operators
    def __str__(self):
        return f"J({self.joint_1}, {self.joint_2}, {self.joint_3}, {self.joint_4}, {self.joint_5}, {self.joint_6})"

    def __iter__(self):
        return iter(asdict(self).items())

    def __add__(self, other):
        self.joint_1 += other.joint_1
        self.joint_2 += other.joint_2
        self.joint_3 += other.joint_3
        self.joint_4 += other.joint_4
        self.joint_5 += other.joint_5
        self.joint_6 += other.joint_6

        return self

    def __sub__(self, other):
        self.joint_1 -= other.joint_1
        self.joint_2 -= other.joint_2
        self.joint_3 -= other.joint_3
        self.joint_4 -= other.joint_4
        self.joint_5 -= other.joint_5
        self.joint_6 -= other.joint_6

        return self

    def __eq__(self, other):
        return (
            self.joint_1 == other.joint_1
            and self.joint_2 == other.joint_2
            and self.joint_3 == other.joint_3
            and self.joint_4 == other.joint_4
            and self.joint_5 == other.joint_5
            and self.joint_6 == other.joint_6
        )

    def __len__(self):
        return len(self.to_list())

    def __getitem__(self, key):
        return getattr(self, key)

    def __setitem__(self, key, value):
        setattr(self, key, value)

    # Utils
    @staticmethod
    def __validate_types(j1, j2, j3, j4, j5, j6):
        """
        Validate the types of the Joint object.

        Args:
            j1: the j1 value
            j2: the j2 value
            j3: the j3 value
            j4: the j4 value
            j5: the j5 value
            j6: the j6 value
        """
        axis_values = [j1, j2, j3, j4, j5, j6]

        for val in axis_values:
            if not isinstance(val, float) and not isinstance(val, int):
                raise ValueError("Expected type float or int for axis, but was received:", type(val))

    @staticmethod
    def from_dict(data_dict):
        """
        Convert a dictionary to a Joint object

        Args:
            data_dict: the dictionary to be converted

        Returns:
            Joint: A Joint object.
        """
        return Joint(**data_dict)

    @staticmethod
    def from_list(data_list):
        """
        Convert a list to a Joint object.

        Args:
            data_list: the list to be converted

        Returns:
            Joint: A Joint object.
        """
        return Joint(*data_list)

    def to_list(self):
        """
        Convert the Joint object to a list.

        Returns:
            list: A list containing the Joint object data.
        """
        return [self.joint_1, self.joint_2, self.joint_3, self.joint_4, self.joint_5, self.joint_6]
