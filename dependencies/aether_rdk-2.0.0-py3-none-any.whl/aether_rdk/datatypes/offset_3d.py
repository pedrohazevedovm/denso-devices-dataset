from dataclasses import asdict, dataclass

from aether_rdk.datatypes.constants import DataType


@dataclass
class Offset3D:
    """
    This class is a data class that represents a robot offset data.
    """

    data_type: DataType = DataType.OFFSET
    x: float = 0
    y: float = 0
    z: float = 0
    rx: float = 0
    ry: float = 0
    rz: float = 0

    # parse to or from
    def __init__(self, x: float, y: float, z: float, rx: float, ry: float, rz: float):
        Offset3D.__validate_types(x, y, z, rx, ry, rz)
        self.x = x
        self.y = y
        self.z = z
        self.rx = rx
        self.ry = ry
        self.rz = rz

    @staticmethod
    def from_dict(data_dict):
        return Offset3D(**data_dict)

    @staticmethod
    def from_list(data_list):
        return Offset3D(*data_list)

    def to_list(self):
        return [self.x, self.y, self.z, self.rx, self.ry, self.rz]

    # built-in operators
    def __iter__(self):
        return iter(asdict(self).items())

    def __str__(self) -> str:
        return f"P({self.x}, {self.y}, {self.z}, {self.rx}, {self.ry}, {self.rz})"

    def __add__(self, other):
        self.x += other.x
        self.y += other.y
        self.z += other.z
        self.rx += other.rx
        self.ry += other.ry
        self.rz += other.rz

        return self

    def __sub__(self, other):
        self.x -= other.x
        self.y -= other.y
        self.z -= other.z
        self.rx -= other.rx
        self.ry -= other.ry
        self.rz -= other.rz

        return self

    def __eq__(self, other):
        return (
            self.x == other.x
            and self.y == other.y
            and self.z == other.z
            and self.rx == other.rx
            and self.ry == other.ry
            and self.rz == other.rz
        )

    def __getitem__(self, key):
        return getattr(self, key)

    def __setitem__(self, key, value):
        setattr(self, key, value)

    # Utils
    @staticmethod
    def __validate_types(x, y, z, rx, ry, rz):
        axis_values = [x, y, z, rx, ry, rz]

        for val in axis_values:
            if not isinstance(val, float) and not isinstance(val, int):
                raise ValueError("Expected type float or int for axis, but was received:", type(val))
