from dataclasses import asdict, dataclass

from aether_rdk.datatypes.constants import DataType


@dataclass
class Pose:
    """
    This class is a data class that represents a robot pose command.
    """

    data_type: DataType = DataType.POSE
    x: float = 0
    y: float = 0
    z: float = 0
    rx: float = 0
    ry: float = 0
    rz: float = 0
    fig: int = 0

    # parse to or from
    def __init__(self, x: float, y: float, z: float, rx: float, ry: float, rz: float, fig: int):
        Pose.__validate_types(x, y, z, rx, ry, rz, fig)
        self.x = x
        self.y = y
        self.z = z
        self.rx = rx
        self.ry = ry
        self.rz = rz
        self.fig = fig

    # built-in operators
    def __str__(self):
        return f"P({self.x}, {self.y}, {self.z}, {self.rx}, {self.ry}, {self.rz}, {self.fig})"

    def __iter__(self):
        return iter(asdict(self).items())

    def __add__(self, other):
        self.x += other.x
        self.y += other.y
        self.z += other.z
        self.rx += other.rx
        self.ry += other.ry
        self.rz += other.rz

        return self

    def __sub__(self, other):
        self.x -= other.x
        self.y -= other.y
        self.z -= other.z
        self.rx -= other.rx
        self.ry -= other.ry
        self.rz -= other.rz

        return self

    def __eq__(self, other):
        return (
            self.x == other.x
            and self.y == other.y
            and self.z == other.z
            and self.rx == other.rx
            and self.ry == other.ry
            and self.rz == other.rz
            and self.fig == other.fig
        )

    def __len__(self):
        return len(self.to_list())

    def __getitem__(self, key):
        return getattr(self, key)

    def __setitem__(self, key, value):
        setattr(self, key, value)

    # Utils
    @staticmethod
    def __validate_types(x, y, z, rx, ry, rz, fig):
        """

        Args:
            x: the x value
            y: the y value
            z: the z value
            rx: the rx value
            ry: the ry value
            rz: the rz value
            fig: the fig value
        """
        axis_values = [x, y, z, rx, ry, rz]

        for val in axis_values:
            if not isinstance(val, float) and not isinstance(val, int):
                raise ValueError("Expected type float or int for axis, but was received:", type(val))

        if not isinstance(fig, int):
            raise ValueError("Expected type int for figure, but was received:", type(fig))

    @staticmethod
    def from_dict(data_dict):
        """
        Convert a dictionary to a Pose object

        Args:
            data_dict: the dictionary to be converted

        Returns:
            Pose: A Pose object.
        """
        return Pose(**data_dict)

    @staticmethod
    def from_list(data_list):
        """
        Convert a list to a Pose object.

        Args:
            data_list: the list to be converted

        Returns:
            Pose: A Pose object.
        """
        return Pose(*data_list)

    def to_list(self):
        """
        Convert the Pose object to a list.

        Returns:
            list: A list containing the values of the Pose
        """
        return [self.x, self.y, self.z, self.rx, self.ry, self.rz, self.fig]
