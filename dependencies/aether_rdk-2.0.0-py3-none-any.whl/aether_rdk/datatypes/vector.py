from math import isclose
from dataclasses import asdict, dataclass

from aether_rdk.datatypes.constants import DataType, TOLERANCE


@dataclass
class Vector:
    """
    This class is a data class that represents a robot Vector command.
    """

    data_type: DataType = DataType.VECTOR
    x: float = 0
    y: float = 0
    z: float = 0

    # parse to or from
    def __init__(self, x, y, z):
        Vector.__validate_types(x, y, z)
        self.x = x
        self.y = y
        self.z = z


    # built-in operators
    def __str__(self):
        return f"V({self.x}, {self.y}, {self.z})"

    def __iter__(self):
        return iter(asdict(self).items())

    def __eq__(self, other):
        current = self.to_list()
        return all([True if isclose(current[n], other[n], abs_tol=TOLERANCE) else False for n in range(len(current))])

    def __len__(self):
        return len(self.to_list())

    def __getitem__(self, key):
        return getattr(self, key)

    def __setitem__(self, key, value):
        setattr(self, key, value)

    # Utils
    @staticmethod
    def __validate_types(x, y, z):
        """
        Validate the types of the Vector object.

        Args:
            x: The x value of the Vector object.
            y: The y value of the Vector object.
            z: The z value of the Vector object.
        """
        axis_values = [x, y, z]

        for val in axis_values:
            if not isinstance(val, float) and not isinstance(val, int):
                raise ValueError("Expected type float or int for axis, but was received:", type(val))

    @staticmethod
    def from_dict(data_dict):
        """
        Convert a dictionary to a Joint object

        Args:
            data_dict: the dictionary to be converted

        Returns:
            Joint: A Joint object.
        """
        return Vector(**data_dict)

    @staticmethod
    def from_list(data_list):
        """
        Convert a list to a Joint object.

        Args:
            data_list: the list to be converted

        Returns:
            Joint: A Joint object.
        """
        return Vector(*data_list)

    def to_list(self):
        """
        Convert the Joint object to a list.

        Returns:
            list: A list containing the Joint object data.
        """
        return [self.x, self.y, self.z]
