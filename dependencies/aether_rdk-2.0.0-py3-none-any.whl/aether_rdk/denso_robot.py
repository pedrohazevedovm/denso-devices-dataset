"""
Module: denso_robot

This module provides the `DensoRobot` class, which manages the functionalities of a Denso robotic system.
It integrates multiple high-level modules to handle robot control, error management, workspace setup,
and motion functionalities.

Dependencies:
    - aether_rdk.low_level
    - aether_rdk.datatypes
    - aether_rdk.high_level
    - aether_rdk.utils
    - random
    - string

Class:
    - DensoRobot: Main class for managing robot connection, control, error handling, and operations.
"""

import random
import string

from aether_rdk.cao import CAOEngineObject, CAOWorkspace, ControllerExecuteEnum, RobotExecuteEnum
from aether_rdk.cao.exceptions import DensoExceptionHandler
from aether_rdk.datatypes import Offset3D
from aether_rdk.high_level import (
    Conversions,
    Gripper,
    ReferenceFrames,
    Robot,
    Tasks,
    Trajectories,
    Transformations,
    Variables,
)
from aether_rdk.utils import error_handler, verify_connection


class DensoRobot:
    """
    A class to manage and control a Denso robotic system.

    This class abstracts various functionalities of the Denso robot using high-level modules,
    including workspace management, robot control, error handling, and transformation utilities.

    Modules:
        conversions: Handles unit conversions for robot parameters.
        gripper: Controls the gripper actions.
        robot: Handles basic robot control (move, stop, etc.).
        tasks: Manages task execution and related operations.
        reference_frames: Handles tool/workspace references for the robot.
        trajectories: Manages trajectory planning and movements.
        transformations: Provides transformation utilities (e.g., coordinate transformations).
        variables: Manages robot variables.

    Args:
        workspace_name: workspace name to create a workspace.
        control_name: control name to create a control.
        options: Server and ip number of robots to connect.
    """

    def __init__(self, workspace_name, control_name, options):
        self.__cao_engine = CAOEngineObject
        self.__cao_workspace = None
        self.__cao_controller = None
        self.__cao_robot = None

        self.__connected = False
        self.__is_take_arm = False

        self.__conversions = None
        self.__gripper = None
        self.__robot = None
        self.__tasks = None
        self.__reference_frames = None
        self.__trajectories = None
        self.__transformations = None
        self.__variables = None

        self.__UNIQUE_SECTION_TOKEN = "".join(random.choices(string.ascii_uppercase + string.digits, k=8))
        self.__WORKSPACE_NAME = f"{workspace_name}_{self.__UNIQUE_SECTION_TOKEN}"
        self.__CONTROLLER_NAME = f"{control_name}_{self.__UNIQUE_SECTION_TOKEN}"
        self.__PROVIDER_NAME = "CaoProv.DENSO.RC8"
        self.__OPTIONS = options

    def __del__(self):
        del self.__conversions
        del self.__gripper
        del self.__robot
        del self.__tasks
        del self.__reference_frames
        del self.__trajectories
        del self.__transformations
        del self.__variables

    def __init_controller_robot_variables(self):
        """
        Method responsible for initializing the controller and robot variables using meta-singleton approach.
        """
        for variable in [var for var in self.__cao_controller.variable_names if "*" not in var]:
            self.__cao_controller.controller_add_variable(variable, "")

        for variable in [var for var in self.__cao_robot.variable_names if "*" not in var]:
            self.__cao_robot.add_variable(variable, "")

    # TODO: Preencher os módulos que não foram feitos ainda
    def __init_modules(self):
        """
        Initializes all high-level modules associated with the robot.
        """
        self.__conversions = Conversions(self, self.__cao_robot)
        self.__gripper = Gripper()
        self.__robot = Robot(self, self.__cao_controller, self.__cao_robot)
        self.__tasks = Tasks(self, self.__cao_controller)
        self.__reference_frames = ReferenceFrames(self, self.__cao_robot)
        self.__trajectories = Trajectories()
        self.__transformations = Transformations()
        self.__variables = Variables(self, self.__cao_controller)

    @property
    def is_connected(self) -> bool:
        """
        Property responsible for checking if the robot is connected.

        Returns:
            bool: True if the robot is connected, False otherwise.
        """
        return self.__connected

    @error_handler
    def connect(self) -> bool:
        """
        Method responsible to connect.

        Returns:
            bool: True if the robot was successfully connected
        Raises:
            DensoExceptionHandler: If an error occurs during the command execution.
        """
        if not self.is_connected:
            self.__cao_workspace = CAOWorkspace(self.__cao_engine.get_dcom_dispatch(), self.__WORKSPACE_NAME)
            self.__cao_controller = self.__cao_workspace.add_controller(
                controller_name=self.__CONTROLLER_NAME,
                provider_name=self.__PROVIDER_NAME,
                machine_name="",
                option=self.__OPTIONS,
            )
            self.__cao_robot = self.__cao_controller.controller_add_robot("Arm", "")
            self.__connected = True

            self.__init_controller_robot_variables()
            self.__init_modules()

            # TODO: Esse método barra de conectar com erros, precisa ser resolvido
            self.take_arm()

            if not self.__reference_frames.tools_tags_reference:
                self.__reference_frames.create_tool_reference(
                    Offset3D(0, 0, 0, 0, 0, 0), self.__reference_frames.default_tool_tag
                )

            self.give_arm()

            return True
        else:
            print("Robot already connected")
            return False

    @error_handler
    def disconnect(self) -> bool:
        """
        Method responsible to give arm, disconnect from the robot and destroy all the objects CAO.

        Returns:
            bool: True if the robot was successfully disconnected.
        """
        if self.is_connected:
            self.give_arm()
            self.__cao_workspace.remove_controller(self.__cao_controller.index)
            self.__cao_engine.workspace_remove(self.__cao_workspace.index)
            self.__connected = False
            self.__is_take_arm = False

            del self.__cao_robot
            del self.__cao_controller
            del self.__cao_workspace

            return True

        else:
            print("Robot is not already connected")
            return False

    @verify_connection
    def remove_workspace(self) -> bool:
        """
        Method responsible for removing the workspace.

        Returns:
            bool: True if the workspace was successfully removed, False otherwise.

        Raises:
            DensoExceptionHandler: if the workspace was not successfully removed.
        """
        names = self.__cao_engine.workspaces_names
        for i in range(len(names)):
            if names[i] == self.__WORKSPACE_NAME:
                self.__cao_engine.workspace_remove(i)

        return True

    @property
    def is_take_arm(self) -> bool:
        """
        Responsible for determining whether the robot's control priority is with the object

        Returns:
            bool: True if priority is with the object.
        """
        return self.__is_take_arm

    @error_handler
    def take_arm(self, inside_params: bool = True) -> bool:
        """
        Method responsible to get the priority from the control the robot

        Args:
            inside_params(bool): True when the method no changes the actual workspace and tool reference on the robot,
            false change the workspace and tool reference to base

        Returns:
            bool: True when the method gets the control of the robot
        """
        if self.__is_take_arm:
            print("Take Arm already enabled")
            return False

        if inside_params:
            self.__cao_robot.execute(RobotExecuteEnum.TakeArm, [0, 1])
        else:
            self.__cao_robot.execute(RobotExecuteEnum.TakeArm, [0, 0])

        self.__is_take_arm = True
        return True

    @error_handler
    def give_arm(self) -> bool:
        """
        Method responsible to return the priority from the control the robot, of the pendant

        Returns:
            bool: True when the method gets the control of the robot, False otherwise
        """
        if not self.__is_take_arm:
            print("Take Arm is not already enabled")
            return False

        self.__cao_robot.execute(RobotExecuteEnum.GiveArm, None)
        self.__is_take_arm = False
        return True

    # TODO: Verificar o caso em que tem erros empilhados
    @verify_connection
    def controller_current_error(self) -> list[DensoExceptionHandler] | bool:
        """
        Method responsible to get the current error from the controller

        Returns:
            list[DensoExceptionHandler]: With the erros into the controller
        """
        errors_list = []
        error_count = self.__cao_controller.execute(ControllerExecuteEnum.GetCurErrorCount)

        if error_count >= 1:
            for i in range(error_count):
                an_error = self.__cao_controller.execute(ControllerExecuteEnum.GetCurErrorInfo, i)
                if len(an_error) != 1:
                    an_error = (an_error,)

                errors_list.append(DensoExceptionHandler(an_error))

        return errors_list

    @verify_connection
    def errors_cleanup(self) -> bool:
        """
        Method responsible to clean up the errors from the controller

        Returns:
            bool: True when the method cleans up the erros into the controller of the robot
        """
        self.__cao_controller.execute(ControllerExecuteEnum.ClearError)
        return True

    @property
    def conversions(self):
        """Returns the Conversions module."""
        return self.__conversions

    @property
    def gripper(self):
        """Returns the Gripper module."""
        return self.__gripper

    @property
    def robot(self):
        """Returns the Robot control module."""
        return self.__robot

    @property
    def tasks(self):
        """Returns the Tasks management module."""
        return self.__tasks

    @property
    def reference_frames(self):
        """Returns the ReferenceFrames module."""
        return self.__reference_frames

    @property
    def trajectories(self):
        """Returns the Trajectories module."""
        return self.__trajectories

    @property
    def transformations(self):
        """Returns the Transformations module."""
        return self.__transformations

    @property
    def variables(self):
        """Returns the Variables module."""
        return self.__variables
