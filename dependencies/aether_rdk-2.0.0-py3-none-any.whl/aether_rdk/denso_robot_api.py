import math
import random
import string

from aether_rdk.cao import (
    CAOEngineObject,
    CAOWorkspace,
    ControllerExecuteEnum,
    RobotExecuteEnum,
)
from aether_rdk.cao.exceptions.denso_exception_handler import DensoExceptionHandler
from aether_rdk.datatypes import DataType, Joint, Pose
from aether_rdk.datatypes.constants import (
    CAOVariableType,
    CartesianAxis,
    TaskExecutionMode,
)
from aether_rdk.datatypes.offset_3d import Offset3D


class DensoRobotAPI:
    def __init__(self, workspace_name, control_name, options):
        self.__cao_engine = CAOEngineObject
        self.__cao_workspace = None
        self.__cao_controller = None
        self.__cao_robot = None
        self.__motor_enabled = False
        self.__connected = False

        self.__UNIQUE_SECTION_TOKEN = "".join(random.choices(string.ascii_uppercase + string.digits, k=8))
        self.__WORKSPACE_NAME = f"{workspace_name}_{self.__UNIQUE_SECTION_TOKEN}"
        self.__CONTROLLER_NAME = f"{control_name}_{self.__UNIQUE_SECTION_TOKEN}"
        self.__PROVIDER_NAME = "CaoProv.DENSO.RC8"
        self.__OPTIONS = options

        self.__added_variable_in_cao = {}
        self.__added_files_in_cao = {}
        self.__added_tasks_in_cao = {}
        self.__FILE_TYPE = [".pcs", ".h"]

        self.__tools_tags_refs = {}
        self.__default_tool_tag = "MECHANICAL_INTERFACE"
        self.__current_tool_tag = self.__default_tool_tag

    def is_connected(self) -> bool:
        return self.__connected

    def motor_enabled(self) -> bool:
        return self.__motor_enabled

    def remove_workspace(self) -> bool:
        if self.__connected:
            try:
                names = self.__cao_engine.workspaces_names
                for i in range(len(names)):
                    if names[i] == self.__WORKSPACE_NAME:
                        self.__cao_engine.workspace_remove(i)

                return True
            except Exception as e:
                raise DensoExceptionHandler(e.args)
        else:
            return False

    def connect(self) -> bool:
        try:
            self.__cao_workspace = CAOWorkspace(self.__cao_engine.get_dcom_dispatch(), self.__WORKSPACE_NAME)
            self.__cao_controller = self.__cao_workspace.add_controller(
                controller_name=self.__CONTROLLER_NAME,
                provider_name=self.__PROVIDER_NAME,
                machine_name="",
                option=self.__OPTIONS,
            )
            self.__cao_robot = self.__cao_controller.controller_add_robot("Arm", "")
            self.__connected = True

            if not self.__tools_tags_refs:
                self.create_tool_reference(Offset3D(0, 0, 0, 0, 0, 0), self.__current_tool_tag)

            return True

        except Exception as e:
            raise DensoExceptionHandler(e.args)

    def disconnect(self) -> bool:
        try:
            self.__cao_workspace.remove_controller(self.__cao_controller.index)
            self.__cao_engine.workspace_remove(self.__cao_workspace.index)
            self.__connected = False

            del self.__cao_robot
            del self.__cao_controller
            del self.__cao_workspace

            return True

        except Exception as e:
            raise DensoExceptionHandler(e.args)

    def controller_current_error(self) -> DensoExceptionHandler | None:
        if self.__connected:
            try:
                error_count = self.__cao_controller.execute(ControllerExecuteEnum.GetCurErrorCount)
                if error_count > 0:
                    error_tuple = self.__cao_controller.execute(ControllerExecuteEnum.GetCurErrorInfo, 0)
                    return DensoExceptionHandler(error_tuple)

            except Exception as e:
                self.__cao_robot.execute(RobotExecuteEnum.GiveArm, None)
                raise DensoExceptionHandler(e.args)
        else:
            print("Robot not connected")
            return False

    def errors_cleanup(self) -> bool:
        if self.__connected:
            try:
                self.__cao_controller.execute(ControllerExecuteEnum.ClearError)

                return True

            except Exception as e:
                self.__cao_robot.execute(RobotExecuteEnum.GiveArm, None)
                raise DensoExceptionHandler(e.args)
        else:
            print("Robot not connected")
            return False

    def motor_on(self) -> bool:
        if self.__connected:
            try:
                self.__cao_robot.execute(RobotExecuteEnum.TakeArm, [0, 0])
                self.__cao_robot.execute(RobotExecuteEnum.Motor, [1, 0])
                self.__motor_enabled = True
                return True

            except Exception as e:
                self.__cao_robot.execute(RobotExecuteEnum.GiveArm, None)
                raise DensoExceptionHandler(e.args)
        else:
            print("Robot not connected")
            return False

    def motor_off(self) -> bool:
        if self.__connected:
            if not self.__motor_enabled:
                print("Motor not enabled to turn off")
                return False

            try:
                self.__cao_robot.execute(RobotExecuteEnum.Motor, [0, 0])
                self.__cao_robot.execute(RobotExecuteEnum.GiveArm, None)
                self.__motor_enabled = False
                return True

            except Exception as e:
                raise DensoExceptionHandler(e.args)
        else:
            print("Robot not connected")
            return False

    def move_joints(self, command: Joint) -> bool:
        if isinstance(command, Joint):
            if not self.__connected or not self.__motor_enabled:
                print("Robot or motor not started")
                return False

            try:
                self.__cao_robot.move(
                    1,
                    [
                        [
                            command.joint_1,
                            command.joint_2,
                            command.joint_3,
                            command.joint_4,
                            command.joint_5,
                            command.joint_6,
                        ],
                        "J",
                        "@E",
                    ],
                    "",
                )

                return True

            except Exception as e:
                raise DensoExceptionHandler(e.args)
        else:
            print("Expected Pose, but was received:", type(command))
            return False

    def move_cartesian(self, command: Pose) -> bool:
        if isinstance(command, Pose):
            if not self.__connected or not self.__motor_enabled:
                print("Robot or motor not started")
                return False

            try:
                self.__cao_robot.move(
                    1,
                    [[command.x, command.y, command.z, command.rx, command.ry, command.rz, command.fig], "P", "@E"],
                    "",
                )

                return True

            except Exception as e:
                raise DensoExceptionHandler(e.args)
        else:
            print("Expected Pose, but was received:", type(command))
            return False

    def move_by_variable(self, cao_type: CAOVariableType, number: int) -> bool:
        """
        Move the robot to a position stored in the selected variable.

        Args:
            cao_type (CAOVariableType): The type of the variable (P or J).
            number (int): The number of the variable.

        Returns:
            bool: The return status of the command. True if the movement was successful, False otherwise.

        Raises:
            DensoExceptionHandler: If an error occurs during the movement.

        Examples:
            move_by_variable(CAOVariableType.P, 1)
            move_by_variable(CAOVariableType.J, 0)
        """

        if (
            isinstance(cao_type, CAOVariableType)
            and isinstance(number, int)
            and self.__has_variable_by_type(cao_type, number)
        ):
            if cao_type == CAOVariableType.J or cao_type == CAOVariableType.P:
                if not self.__connected or not self.__motor_enabled:
                    print("Robot or motor not started")
                    return False

                try:
                    movement = f"{cao_type}{number}"
                    self.__cao_robot.move(1, movement, "")
                    return True

                except Exception as e:
                    raise DensoExceptionHandler(e.args)
        else:
            print("Expected types CAOVariableType and int, but was received:", type(cao_type), type(number))
            return False

    def get_joints_pose(self) -> Joint | None:
        if not self.__connected:
            print("Robot not connected")
            return None

        try:
            joints = self.__cao_robot.execute(RobotExecuteEnum.CurJnt, [])

            return Joint(joints[0], joints[1], joints[2], joints[3], joints[4], joints[5])

        except Exception as e:
            raise DensoExceptionHandler(e.args)

    def get_cartesian_pose(self) -> Pose | None:
        if not self.__connected:
            print("Robot not connected")
            return None

        try:
            pose = self.__cao_robot.execute(RobotExecuteEnum.CurPos, [])

            return Pose(pose[0], pose[1], pose[2], pose[3], pose[4], pose[5], int(pose[6]))

        except Exception as e:
            raise DensoExceptionHandler(e.args)

    def set_arm_speed(self, speed, accel, decel) -> bool:
        param_list = [speed, accel, decel]

        if DensoRobotAPI.__validate_numeric_type(param_list) and DensoRobotAPI.__in_numeric_range(param_list, 1, 100):
            try:
                self.__cao_robot.execute(RobotExecuteEnum.ExtSpeed, param_list)
                return True
            except Exception as e:
                raise DensoExceptionHandler(e.args)
        else:
            return False

    def get_current_arm_speed(self) -> tuple | None:
        if not self.__connected:
            print("Robot not connected")
            return None

        try:
            speed = self.__cao_robot.execute(RobotExecuteEnum.CurExtSpd, 0)
            accel = self.__cao_robot.execute(RobotExecuteEnum.CurExtAcc, 0)
            decel = self.__cao_robot.execute(RobotExecuteEnum.CurExtDec, 0)
            return speed, accel, decel

        except Exception as e:
            raise DensoExceptionHandler(e.args)

    def emergency_stop(self) -> bool:
        if not self.__connected:
            print("Robot not connected")
            return False

        try:
            self.__cao_controller.execute(ControllerExecuteEnum.SuspendAll)
            self.__cao_controller.execute(ControllerExecuteEnum.KillAll)
            return True
        except Exception as e:
            raise DensoExceptionHandler(e.args)

    def get_current_fig(self) -> int | None:
        if not self.__connected:
            print("Robot not connected")
            return None

        try:
            return self.__cao_robot.execute(RobotExecuteEnum.CurFig, [])
        except Exception as e:
            raise DensoExceptionHandler(e.args)

    def is_out_of_range(self, robot_command: Pose | Joint) -> bool | None:
        if isinstance(robot_command, Pose) or isinstance(robot_command, Joint):
            if not self.__connected:
                print("Robot not connected")
                return None

            try:
                str_comm = ""
                if robot_command.data_type == DataType.JOINT:
                    str_comm = (
                        f"J({str(robot_command.joint_1)}, {str(robot_command.joint_2)}, "
                        + f"{str(robot_command.joint_3)}, {str(robot_command.joint_4)}, "
                        + f"{str(robot_command.joint_5)}, {str(robot_command.joint_6)})"
                    )
                elif robot_command.data_type == DataType.POSE:
                    str_comm = (
                        f"P({str(robot_command.x)}, {str(robot_command.y)}, {str(robot_command.z)}, "
                        + f"{str(robot_command.rx)}, {str(robot_command.ry)}, {str(robot_command.rz)}, "
                        + f"{str(int(robot_command.fig))})"
                    )

                res = self.__cao_robot.execute(RobotExecuteEnum.OutRange, str_comm)
                return res != 0
            except Exception as e:
                raise DensoExceptionHandler(e.args)
        else:
            print("Expected Robot command types, but was received:", type(robot_command))
            return None

    def joint_to_cartesian(self, command: Joint) -> Pose | None:
        if isinstance(command, Joint):
            if not self.__connected:
                print("Robot not connected")
                return None

            try:
                str_comm = (
                    f"J({str(command.joint_1)}, {str(command.joint_2)}, {str(command.joint_3)}, "
                    + f"{str(command.joint_4)}, {str(command.joint_5)}, {str(command.joint_6)})"
                )

                pose = self.__cao_robot.execute(RobotExecuteEnum.J2P, str_comm)

                return Pose(pose[0], pose[1], pose[2], pose[3], pose[4], pose[5], int(pose[6]))
            except Exception as e:
                raise DensoExceptionHandler(e.args)
        else:
            print("Expected Joint, but was received:", type(command))
            return None

    def cartesian_to_joint(self, command: Pose) -> Joint | None:
        if isinstance(command, Pose):
            try:
                str_comm = (
                    f"P({str(command.x)}, {str(command.y)}, {str(command.y)}, "
                    + f"{str(command.rx)}, {str(command.ry)}, {str(command.rz)})"
                )

                joints = self.__cao_robot.execute(RobotExecuteEnum.P2J, str_comm)

                return Joint(joints[0], joints[1], joints[2], joints[3], joints[4], joints[5])
            except Exception as e:
                raise DensoExceptionHandler(e.args)
        else:
            print("Expected Pose, but was received:", type(command))

    @staticmethod
    def __validate_numeric_type(value_list) -> bool:
        for val in value_list:
            if not isinstance(val, float) and not isinstance(val, int):
                print("Expected float or int, but was received:", type(val))
                return False

        return True

    @staticmethod
    def __in_numeric_range(value_list, range_min, range_max):
        for val in value_list:
            if not (range_min <= val <= range_max):
                print(
                    "Expected values between range [" + str(range_min) + ", " + str(range_max) + "] but was received:",
                    val,
                )
                return False

        return True

    def has_file_in_controller(self, file_name: str) -> bool:
        """
        Checks if a file exists in the robot controller.

        Parameters:
            file_name (str): The name of the file to check.

        Returns:
            bool: True if the file exists, False otherwise.

        Raises:
            DensoExceptionHandler: If an exception occurs during the check process.
        """
        if self.__connected:
            try:
                current_files = self.__cao_controller.file_names

                return file_name in current_files
            except Exception as e:
                raise DensoExceptionHandler(e.args)
        else:
            return False

    def __file_extension_check(self, file_name: str):
        for ext in self.__FILE_TYPE:
            if ext in file_name:
                return True

        raise ValueError(f"File name extension not expected! Expect: {self.__FILE_TYPE}")

    def create_file(self, file_name: str, content: str) -> bool:
        """
        Creates a file with the given file name and content in the robot controller.

        Parameters:
            file_name (str): The name of the file to be created.
            content (str): The content to be written in the file.

        Returns:
            bool: True if the file is created successfully, False otherwise.

        Raises:
            FileExistsError: If the file already exists in the controller.
            DensoExceptionHandler: If any exception occurs during the file creation process.
            ValueError: If the script_name does not have the expected file extension.
        """
        if self.__connected:
            if self.__file_extension_check(file_name):
                try:
                    if not self.has_file_in_controller(file_name) and not (
                        file_name in self.__added_files_in_cao.keys()
                    ):
                        file_obj = self.__cao_controller.controller_add_file(file_name, "@Create=1")
                        file_obj.value = content
                        self.__added_files_in_cao[file_name] = file_obj
                        return True
                    else:
                        raise FileExistsError(f"File {file_name} already exists in the controller!")
                except Exception as e:
                    raise DensoExceptionHandler(e.args)
        else:
            return False

    def update_file(self, file_name: str, content: str) -> bool:
        """
        Override full content of a file in the robot controller.

        Parameters:
            file_name (str): The name of the file to be updated.
            content (str): The new content to be written to the file.

        Returns:
            bool: True if the file was successfully updated, False otherwise.

        Raises:
            FileNotFoundError: If the file does not exist in the robot controller.
            DensoExceptionHandler: If an exception occurs during the update process.
        """
        if self.__connected:
            try:
                if self.has_file_in_controller(file_name):
                    # Create symbolic link with DCOM or get of dict of objects links
                    if file_name in self.__added_files_in_cao.keys():
                        file_obj = self.__added_files_in_cao[file_name]
                        file_obj.value = content
                    else:
                        file_obj = self.__cao_controller.controller_add_file(file_name)
                        file_obj.value = content
                        self.__added_files_in_cao[file_name] = file_obj
                    return True
                else:
                    raise FileNotFoundError(f"File {file_name} not found in controller!")
            except Exception as e:
                raise DensoExceptionHandler(e.args)
        else:
            return False

    def get_file_content(self, file_name: str) -> str:
        """
        Retrieves the content of a file from the robot controller.

        Parameters:
            file_name (str): The name of the file to retrieve.

        Returns:
            str: The content of the file.

        Raises:
            FileNotFoundError: If the file is not found in the robot controller.
            DensoExceptionHandler: If any other exception occurs during the retrieval process.
        """
        if self.__connected:
            try:
                if self.has_file_in_controller(file_name):
                    # Create symbolic link with DCOM or get of dict of objects links
                    if file_name in self.__added_files_in_cao.keys():
                        file_obj = self.__added_files_in_cao[file_name]
                        return file_obj.value
                    else:
                        file_obj = self.__cao_controller.controller_add_file(file_name)
                        self.__added_files_in_cao[file_name] = file_obj
                        return file_obj.value
                else:
                    raise FileNotFoundError(f"File {file_name} not found in controller!")
            except Exception as e:
                raise DensoExceptionHandler(e.args)

    def __has_variable_by_type(self, cao_type: CAOVariableType, number: int) -> bool:
        if cao_type == CAOVariableType.IO:
            # TODO: Check range for IO variables
            return True

        max_number = 100
        if (
            cao_type == CAOVariableType.D
            or cao_type == CAOVariableType.V
            or cao_type == CAOVariableType.T
            or cao_type == CAOVariableType.S
        ):
            max_number = 50

        has_variable = number < max_number
        if not has_variable:
            raise IndexError(f"Variable number out of range for type: {cao_type.name}")

        return has_variable

    def __variable_in_range_by_type(self, cao_type: CAOVariableType, value) -> bool:
        if cao_type == CAOVariableType.I:
            return isinstance(value, int)
        if cao_type == CAOVariableType.F or cao_type == CAOVariableType.D:
            return isinstance(value, float)
        if cao_type == CAOVariableType.S:
            return isinstance(value, str) and (len(value) <= 243)
        if cao_type == CAOVariableType.V:
            return isinstance(value, tuple) and (len(value) == 3)
        if cao_type == CAOVariableType.P:
            return isinstance(value, tuple) and (len(value) == 7)
        if cao_type == CAOVariableType.T:
            return isinstance(value, tuple) and (len(value) == 9)
        if cao_type == CAOVariableType.J:
            return isinstance(value, tuple) and (len(value) == 6)
        if cao_type == CAOVariableType.IO:
            return isinstance(value, int) and (value == 0 or value == 1)

    def get_variable_content(self, cao_type: CAOVariableType, number: int):
        """
        Retrieves the content of a variable based on its type and number.

        Parameters:
            cao_type (CAOVariableType): The type of the variable.
            number (int): The index of the variable.

        Returns:
            Corresponding variable content based on the type:
            - For Type I: Integer
            - For Type F or D: Float
            - For Type S: String with length is less than or equal to 243
            - For Type V: Tuple with a length of 3
            - For Type P: Tuple with a length of 7
            - For Type T: Tuple with a length of 9
            - For Type J: Tuple with a length of 6
            - For Type IO: Integer with value 0 or 1

        Raises:
            IndexError: If the index is out of range for type.
            DensoExceptionHandler: If an error occurs while retrieving the variable content.
            TypeError: If the cao_type parameter is not of type CAOVariableType.
        """
        if self.__connected:
            if isinstance(cao_type, CAOVariableType):
                try:
                    if self.__has_variable_by_type(cao_type, number):
                        variable_key = f"{cao_type}{number}"
                        # Create symbolic link with DCOM or get of dict of objects links
                        if variable_key in self.__added_variable_in_cao.keys():
                            var_obj = self.__added_variable_in_cao[variable_key]
                            return var_obj.value
                        else:
                            var_obj = self.__cao_controller.controller_add_variable(variable_key)
                            self.__added_variable_in_cao[variable_key] = var_obj
                            return var_obj.value

                except Exception as e:
                    raise DensoExceptionHandler(e.args)
            else:
                raise TypeError("Expected CAOVariableType, but was received:", type(cao_type))

    def set_variable_content(self, cao_type: CAOVariableType, number: int, new_value) -> bool:
        """
        Set the content of a variable of selected type and number with the new_value.

        Parameters:
            cao_type (CAOVariableType): The type of the variable.
            number (int): The number of the variable.
            new_value: The new value to assign to the variable, based on the type:
            - For Type I: Integer
            - For Type F or D: Float
            - For Type S: String with length is less than or equal to 243
            - For Type V: Tuple with a length of 3
            - For Type P: Tuple with a length of 7
            - For Type T: Tuple with a length of 9
            - For Type J: Tuple with a length of 6
            - For Type IO: Integer with value 0 or 1

        Returns:
            bool: True if the content was set successfully, False otherwise.

        Raises:
            ValueError: If the new value does not match the requirements for the given variable type.
            IndexError: If the index is out of range for type.
            TypeError: If the provided cao_type is not an instance of CAOVariableType.
            DensoExceptionHandler: If an exception occurs while setting the variable content.
        """
        if self.__connected:
            if isinstance(cao_type, CAOVariableType):
                if self.__has_variable_by_type(cao_type, number) and self.__variable_in_range_by_type(
                    cao_type, new_value
                ):
                    try:
                        variable_key = f"{cao_type}{number}"
                        # Create symbolic link with DCOM or get of dict of objects links
                        if variable_key in self.__added_variable_in_cao.keys():
                            var_obj = self.__added_variable_in_cao[variable_key]
                            var_obj.value = new_value
                        else:
                            var_obj = self.__cao_controller.controller_add_variable(variable_key)
                            self.__added_variable_in_cao[variable_key] = var_obj
                            var_obj.value = new_value

                        return True

                    except Exception as e:
                        raise DensoExceptionHandler(e.args)
                else:
                    raise ValueError(
                        f"Receive {new_value} for type {cao_type.name}, value does not match with the requirements"
                    )
            else:
                raise TypeError("Expected CAOVariableType, but was received:", type(cao_type))

    def execute_script_task(self, script_name: str, mode: TaskExecutionMode) -> bool:
        """
        Execute a script task with the given script name and execution mode.

        Parameters:
            script_name (str): The name of the script to execute.
            mode (TaskExecutionMode): The mode in which the task should be executed.

        Returns:
            bool: True if the task was executed successfully, False otherwise.

        Raises:
            ValueError: If the script_name does not have the expected file extension.
            FileNotFoundError: If the script file is not found or not available for execution.
            TypeError: If the provided mode is not an instance of TaskExecutionMode.
            DensoExceptionHandler: If an exception occurs during task execution.
        """
        if self.__connected:
            if self.__file_extension_check(script_name) and self.has_file_in_controller(script_name):
                if isinstance(mode, TaskExecutionMode):
                    try:
                        script_name = script_name.replace(".pcs", "")
                        # Create symbolic link with DCOM or get of dict of objects links
                        if script_name in self.__added_tasks_in_cao.keys():
                            task_obj = self.__added_tasks_in_cao[script_name]
                            task_obj.start(mode.value)
                        else:
                            task_obj = self.__cao_controller.controller_add_task(script_name)
                            task_obj.start(mode.value)
                            self.__added_tasks_in_cao[script_name] = task_obj

                        return True

                    except Exception as e:
                        raise DensoExceptionHandler(e.args)
                else:
                    raise TypeError("Expected TaskExecutionMode, but was received:", type(mode))
            else:
                raise FileNotFoundError(f"Script {script_name} not found or not available to execute")
        else:
            return False

    def dist_to(self, target_pose: Pose | Joint) -> tuple | float:
        """
        Calculates the distance between the current pose of the robot and the target pose specified in the target_pose.

        Parameters:
            target_pose (Pose | Joint): The target pose to calculate the distance to.

        Returns:
            tuple: If the target_pose is of type DataType.POSE, returns a tuple containing the Euclidean
            distance in Cartesian coordinates (x, y, z) and the rotational distance (rx, ry, rz).

            float: If the target_pose is of type DataType.JOINT, returns the Euclidean distance in
            joint coordinates (j1, j2, j3, j4, j5, j6).
        """
        if target_pose.data_type == DataType.POSE:
            current_pose = self.get_cartesian_pose()
            dist_x = target_pose.x - current_pose.x
            dist_y = target_pose.y - current_pose.y
            dist_z = target_pose.z - current_pose.z
            dist_rx = target_pose.rx - current_pose.rx
            dist_ry = target_pose.ry - current_pose.ry
            dist_rz = target_pose.rz - current_pose.rz
            return math.sqrt(dist_x**2 + dist_y**2 + dist_z**2), math.sqrt(dist_rx**2 + dist_ry**2 + dist_rz**2)

        elif target_pose.data_type == DataType.JOINT:
            current_joint_pose = self.get_joints_pose()
            dist_j1 = target_pose.joint_1 - current_joint_pose.joint_1
            dist_j2 = target_pose.joint_2 - current_joint_pose.joint_2
            dist_j3 = target_pose.joint_3 - current_joint_pose.joint_3
            dist_j4 = target_pose.joint_4 - current_joint_pose.joint_4
            dist_j5 = target_pose.joint_5 - current_joint_pose.joint_5
            dist_j6 = target_pose.joint_6 - current_joint_pose.joint_6
            return math.sqrt(dist_j1**2 + dist_j2**2 + dist_j3**2 + dist_j4**2 + dist_j5**2 + dist_j6**2)

    # TODO: transformar default_tool_tag em property
    def default_tool_tag(self) -> str:
        """
        Return tag of default tool of robot, the mechanical interface
        """
        return self.__default_tool_tag

    def create_tool_reference(self, offset_base: Offset3D, tag: str) -> bool:
        """
        Creates a tool reference with specific offsets for each Cartesian axis (X, Y, Z) based on a given base offset.

        Note: See manual in RC8UserManuals_2201_en/en/001944.html for more information about create a definition of tools.

        Args:
            offset_base (Offset3D): The base offset values (position and rotation) for defining the tool.
            tag (str): A unique identifier for the tool being created, for future uses

        Returns:
            bool: True if the task was executed successfully, False otherwise.

        Raises:
            DensoExceptionHandler: If an error occurs during the movement execution.
        """
        offset_for_move_x = Offset3D(
            offset_base.x, offset_base.y, offset_base.z, offset_base.rx, offset_base.ry + 90, offset_base.rz
        )
        offset_for_move_y = Offset3D(
            offset_base.x, offset_base.y, offset_base.z, offset_base.rx - 90, offset_base.ry, offset_base.rz
        )
        offset_for_move_z = offset_base

        number_base = len(self.__tools_tags_refs.keys()) * 3 + 1
        elements = [
            (CartesianAxis.X, number_base, offset_for_move_x),
            (CartesianAxis.Y, number_base + 1, offset_for_move_y),
            (CartesianAxis.Z, number_base + 2, offset_for_move_z),
        ]

        if self.__connected:
            try:
                if not self.__motor_enabled:
                    self.__cao_robot.execute(RobotExecuteEnum.TakeArm, [0, 0])

                self.__tools_tags_refs[tag] = {}
                for axis, num, offset in elements:
                    self.__cao_robot.execute(RobotExecuteEnum.SetToolDef, [num, str(offset)])
                    self.__tools_tags_refs[tag][axis] = f"Tool{num}"

                if not self.__motor_enabled:
                    self.__cao_robot.execute(RobotExecuteEnum.GiveArm, None)

                return True
            except Exception as e:
                raise DensoExceptionHandler(e.args)
        else:
            print("Robot not connected")
            return False

    def set_current_tool_by_tag(self, tag: str) -> bool:
        """
        Change current tool used for movement in tool reference.

        Returns:
            bool: True if the Change was executed successfully, False otherwise.
        """
        if tag in self.__tools_tags_refs.keys():
            self.__current_tool_tag = tag
            return True

        return False

    def move_in_tool_reference(
        self,
        axis: CartesianAxis,
        linear_step: int | float,
    ) -> bool:
        """
        Moves the robot along a specified Cartesian axis using the current tool as a reference.

        This method executes a movement along the given `axis` (X, Y, or Z) using a step value in `millimeters`,
        adjusted by the current tool reference. It switches to the tool defined for the specified axis, performs the movement,
        and then restores the previous tool configuration.

        Args:
            axis (CartesianAxis): The axis along which the robot should move (X, Y, or Z).
            linear_step (int | float): The step value to move along the axis. Positive values indicate forward movement,
                                    while negative values indicate backward movement.

        Returns:
            bool: True if the task was executed successfully, False otherwise.

        Raises:
            DensoExceptionHandler: If an error occurs during the movement execution.
        """

        valid_parameters = isinstance(axis, CartesianAxis) and (
            isinstance(linear_step, float) or isinstance(linear_step, int)
        )

        if valid_parameters:
            if self.__connected and self.__motor_enabled:
                try:
                    base_tool = self.__cao_robot.execute(RobotExecuteEnum.CurTool)
                    desired_tool = self.__tools_tags_refs[self.__current_tool_tag][axis]
                    self.__cao_robot.change(desired_tool)

                    linear_step *= -1

                    self.__cao_robot.execute(RobotExecuteEnum.Depart, [1, "@P " + str(linear_step)])

                    self.__cao_robot.change(f"Tool{base_tool}")

                    return True

                except Exception as e:
                    raise DensoExceptionHandler(e.args)
            else:
                print("Robot or motor not started")
        else:
            print("Expected types CartesianAxis and int/float, but was received:", type(axis), type(linear_step))

        return False

    def rotate_in_tool_reference(
        self,
        axis: CartesianAxis,
        angle_step: int | float,
    ) -> bool:
        """
        Rotate the robot along a specified Cartesian axis using the current tool as a reference.

        This method executes a movement along the given `axis` (X, Y, or Z) using a step value in `degrees`,
        adjusted by the current tool reference. It switches to the tool defined for the specified axis, performs the movement,
        and then restores the previous tool configuration.

        Args:
            axis (CartesianAxis): The axis along which the robot should move (X, Y, or Z).
            angle_step (int | float): The step value to move along the axis. Positive values indicate forward movement,
                                    while negative values indicate backward movement.

        Returns:
            bool: True if the task was executed successfully, False otherwise.

        Raises:
            DensoExceptionHandler: If an error occurs during the movement execution.
        """
        valid_parameters = isinstance(axis, CartesianAxis) and (
            isinstance(angle_step, float) or isinstance(angle_step, int)
        )
        if valid_parameters:
            if self.__connected and self.__motor_enabled:
                try:
                    base_tool = self.__cao_robot.execute(RobotExecuteEnum.CurTool)
                    desired_tool = self.__tools_tags_refs[self.__current_tool_tag][axis]
                    self.__cao_robot.change(desired_tool)

                    self.__cao_robot.execute(RobotExecuteEnum.RotateH, [angle_step, "@P"])

                    self.__cao_robot.change(f"Tool{base_tool}")

                    return True

                except Exception as e:
                    raise DensoExceptionHandler(e.args)
            else:
                print("Robot or motor not started")
        else:
            print("Expected types CartesianAxis and int/float, but was received:", type(axis), type(angle_step))

        return False
