from time import sleep

from aether_rdk.denso_robot_api import DensoRobotAPI
from aether_rdk.datatypes.constants import CAOVariableType, DensoCommunicationStatus, TaskExecutionMode


class DensoSerialCommunication:
    """
    Class representing the serial communication functionality for Denso robots.

    This class provides methods to write and read values over a builtin serial (RS-232) connection
    with a Denso robot controller.

    Methods:
        write_value(value: str) -> bool:
            Writes a value over the serial connection.
        read_value(timeout_ms: int = -1) -> str:
            Reads a value from the serial connection.
        communication_status() -> DensoCommunicationStatus | None:
            Retrieves the communication status over the serial connection.
        available_to_read() -> int:
            Retrieves the number of available values to read from the serial connection.
    """

    def __init__(self, robot_api: DensoRobotAPI):
        """
        Initializes a new instance of the DensoSerialCommunication class.

        Parameters:
            robot_api (DensoRobotAPI): An instance of the DensoRobotAPI class for
                interacting with the robot controller.
        """

        self.__robot_api = robot_api
        self.__serial_write_script_name = "aether_serial_comm_write.pcs"
        self.__serial_write_script = """
        '!TITLE "AETHER SERIAL WRITE COMM"
        Sub Main
            Comm.Open 1
            Comm.Output 1, S[0]
            Comm.Close 1
        End Sub"""

        self.__serial_read_script_name = "aether_serial_comm_read.pcs"
        self.__serial_read_script = """
        '!TITLE "AETHER SERIAL READ COMM"
        Sub Main
            Comm.Open 1
            S[1] = ""
            S[1] = Comm.Input(1, I[0])
            Comm.Close 1
        End Sub"""

        self.__serial_status_script_name = "aether_serial_comm_status.pcs"
        self.__serial_status_script = """
        '!TITLE "AETHER SERIAL STATUS COMM"
        Sub Main
            I[1] = -1
            I[2] = -1
            Comm.Open 1
            I[1] = Comm.State(1)
            I[2] = Comm.Count(1)
            Comm.Close 1
        End Sub"""

        self.__setup_communication()

    def __setup_communication(self):
        """
        Sets up the communication by creating or updating the script files on the robot controller.
        """
        # write script
        if self.__robot_api.has_file_in_controller(self.__serial_write_script_name):
            self.__robot_api.update_file(self.__serial_write_script_name, self.__serial_write_script)
        else:
            self.__robot_api.create_file(self.__serial_write_script_name, self.__serial_write_script)

        # read script
        if self.__robot_api.has_file_in_controller(self.__serial_read_script_name):
            self.__robot_api.update_file(self.__serial_read_script_name, self.__serial_read_script)
        else:
            self.__robot_api.create_file(self.__serial_read_script_name, self.__serial_read_script)

        # status script
        if self.__robot_api.has_file_in_controller(self.__serial_status_script_name):
            self.__robot_api.update_file(self.__serial_status_script_name, self.__serial_status_script)
        else:
            self.__robot_api.create_file(self.__serial_status_script_name, self.__serial_status_script)

    def write_value(self, value: str) -> bool:
        """
        Writes a value over the serial connection.

        Parameters:
            value (str): The value to write.

        Returns:
            bool: True if the write operation was successful, False otherwise.

        Raises:
            ValueError: If the string length of the value is greater than 243.
        """
        self.__robot_api.set_variable_content(CAOVariableType.S, 0, value)
        return self.__robot_api.execute_script_task(
            self.__serial_write_script_name, TaskExecutionMode.ONE_CYCLE_EXECUTION
        )

    def read_value(self, timeout_ms: int = -1) -> str:
        # FIXME: This method is not working. The robot is not reading any value from the serial connection.
        """
        Reads a value from the serial connection.

        Args:
            timeout_ms (int, optional): The timeout in milliseconds for the read operation.
                Defaults to -1, which means no timeout.

        Returns:
            str: The value read from the serial connection.
        """
        if self.__robot_api.set_variable_content(CAOVariableType.I, 0, timeout_ms):
            sleep(1 + int(timeout_ms / 1e3))
            return self.__robot_api.get_variable_content(CAOVariableType.S, 1)

    def communication_status(self) -> DensoCommunicationStatus | None:
        """
        Retrieves the communication status over the serial connection, in communication serial mode not is necessary check the status.

        Returns:
            DensoCommunicationStatus | None: The communication status, or None if the status
                could not be retrieved.
        """
        if self.__robot_api.execute_script_task(
            self.__serial_status_script_name, TaskExecutionMode.ONE_CYCLE_EXECUTION
        ):
            status = self.__robot_api.get_variable_content(CAOVariableType.I, 1)

            if 0 <= status <= 3:
                return DensoCommunicationStatus(status)

    def available_to_read(self) -> int:
        """
        Retrieves the number of available values to read from the serial connection.

        Returns:
            int: The number of available values to read.
        """
        if self.__robot_api.execute_script_task(
            self.__serial_status_script_name, TaskExecutionMode.ONE_CYCLE_EXECUTION
        ):
            return self.__robot_api.get_variable_content(CAOVariableType.I, 2)
