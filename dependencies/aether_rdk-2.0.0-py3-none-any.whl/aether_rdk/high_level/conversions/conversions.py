from aether_rdk.cao import RobotExecuteEnum
from aether_rdk.datatypes import DensoHomogeneousTranslation, HomogeneousTranslation, Joint, Pose
from aether_rdk.utils import error_handler_cls


@error_handler_cls
class Conversions:
    """
    This class is responsible for converting robot datatypes.
    In this API, we have the following datatypes: Pose, Joint, HomogeneousTranslation and DensoHomogeneousTranslation.

    The authors of this API have opted to use just a proper datatype for the HomogeneousTranslation, which
    represents the homogeneous transformations matrix of the robot.

    The robot's internal representation of the homogeneous transformations matrix is called DensoHomogeneousTranslation.

    All robot methods that use the homogeneous transformations matrix convert the HomogeneousTranslation to
    DensoHomogeneousTranslation before sending to the robot.

    For users is appropriate to use the HomogeneousTranslation datatype, because it is more intuitive to understand
    and is easier to manipulate the homogeneous transformations' matrix.

    """

    def __init__(self, api_context, cao_robot):
        self.api_context = api_context
        self.__cao_robot = cao_robot
        self.__connected = False

    def joint_to_pose(self, joints: Joint) -> Pose | None:
        """
        Convert joint to pose using robot conversions.

        Args:
            joints: The Joint object to convert

        Returns:
            Pose: The converted Pose object
        """
        if not isinstance(joints, Joint):
            raise TypeError(f"Expected Joint, but {type(joints)} was received")

        joint_string = str(joints)

        pose = self.__cao_robot.execute(RobotExecuteEnum.J2P, joint_string)
        pose = pose[0:-1] + (int(pose[-1]),)

        return Pose(*pose)

    def pose_to_joint(self, pose: Pose) -> Joint | None:
        """
        Convert pose to joint using robot conversions.

        Args:
            pose: The Pose object to convert

        Returns:
            Joint: The converted Joint object
        """
        if not isinstance(pose, Pose):
            raise TypeError(f"Expected Pose, but {type(pose)} was received")

        pose_string = str(pose)
        joints = self.__cao_robot.execute(RobotExecuteEnum.P2J, pose_string)
        return Joint(*joints[:-2])

    def joint_to_homogeneous_translation(self, joints: Joint) -> HomogeneousTranslation | None:
        """
        This method converts a Joint object to a HomogeneousTranslation object.

        Args:
            joints: The Joint object to convert

        Returns:
            HomogeneousTranslation: The converted HomogeneousTranslation object
        """
        if not isinstance(joints, Joint):
            raise TypeError(f"Expected Joint, but {type(joints)} was received")

        joint_string = str(joints)

        dht_response = self.__cao_robot.execute(RobotExecuteEnum.J2T, joint_string)
        dht_response = dht_response[0:-1] + (int(dht_response[-1]),)

        dht = DensoHomogeneousTranslation.from_list(dht_response)
        homogeneous_translation = HomogeneousTranslation.from_dht(dht)

        return homogeneous_translation

    def pose_to_homogeneous_translation(self, pose: Pose) -> HomogeneousTranslation | None:
        """
        This method converts a Pose object to a HomogeneousTranslation object.

        Args:
            pose: The Pose object to convert

        Returns:
            HomogeneousTranslation: The converted HomogeneousTranslation object
        """
        if not isinstance(pose, Pose):
            raise TypeError(f"Expected Pose, but {type(pose)} was received")

        pose_string = str(pose)

        dht_response = self.__cao_robot.execute(RobotExecuteEnum.P2T, pose_string)
        dht_response = dht_response[0:-1] + (int(dht_response[-1]),)

        dht = DensoHomogeneousTranslation.from_list(dht_response)
        homogeneous_translation = HomogeneousTranslation.from_dht(dht)

        return homogeneous_translation

    def homogeneous_translation_to_joint(self, homogeneous_translation: HomogeneousTranslation) -> Joint | None:
        """
        Convert homogeneous translation to joint.

        Args:
            homogeneous_translation: The HomogeneousTranslation object to convert

        Returns:
            Joint: The converted Joint object
        """
        if not isinstance(homogeneous_translation, HomogeneousTranslation):
            raise TypeError(f"Expected HomogeneousTranslation, but {type(homogeneous_translation)} was received")

        homogeneous_translation = homogeneous_translation.to_dht()
        homogeneous_translation_string = str(homogeneous_translation)
        joints = self.__cao_robot.execute(RobotExecuteEnum.T2J, homogeneous_translation_string)

        return Joint(*joints[0:-2])

    def homogeneous_translation_to_pose(self, homogeneous_translation: HomogeneousTranslation) -> Pose | None:
        """
        Convert homogeneous translation to pose.

        Args:
            homogeneous_translation: The HomogeneousTranslation object to convert

        Returns:
            Pose: The converted Pose object
        """
        if not isinstance(homogeneous_translation, HomogeneousTranslation):
            raise TypeError(f"Expected HomogeneousTranslation, but {type(homogeneous_translation)} was received")

        homogeneous_translation = homogeneous_translation.to_dht()
        homogeneous_translation_string = str(homogeneous_translation)

        pose = self.__cao_robot.execute(RobotExecuteEnum.T2P, homogeneous_translation_string)
        pose = pose[0:-1] + (int(pose[-1]),)

        return Pose(*pose)
