class Gripper:
    """
    This class is used to control the electric gripper of the robot.
    In the future, this class supports any electric gripper if the gripper interface is respected.
    The interface will still be defined in the future.
    """

    ...
