import numpy as np

from aether_rdk.high_level.reference_frames.zone import Zone


class Cuboid(Zone):
    """
    Class that defines a cuboid in the robot's coordinate system.
    """

    def __init__(self, reference_zone, zone_dimensions):
        """
        Defines a cuboid with reference and dimensions.

        Args:
            reference_zone: Center of the cuboid [x, y, z] in the robot's coordinate system.
            zone_dimensions: Dimensions of the cuboid [x, y, z].
        """
        super().__init__(reference_zone)
        self.zone_dimensions = np.array(zone_dimensions)

    def is_contained(self, position):
        """
        Verify if the position is inside the cuboid.

        Args:
            position: the position to be verified [x, y, z].

        Returns:
            True if the position is inside the cuboid, False otherwise.
        """
        position = np.array(position)
        inferior_limit = self.reference_zone - self.zone_dimensions
        superior_limit = self.reference_zone + self.zone_dimensions

        return np.all(position >= inferior_limit) and np.all(position <= superior_limit)
