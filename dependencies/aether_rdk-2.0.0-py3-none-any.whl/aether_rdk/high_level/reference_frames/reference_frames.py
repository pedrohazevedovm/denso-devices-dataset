from aether_rdk.cao import RobotExecuteEnum
from aether_rdk.datatypes import CAOReferenceType, CartesianAxis, Offset3D, Vector
from aether_rdk.high_level.reference_frames.zone import Zone
from aether_rdk.high_level.utils import has_reference_by_type
from aether_rdk.utils import error_handler_cls, verify_motor_on, verify_take_arm


@error_handler_cls
class ReferenceFrames:
    """
    This class is responsible for manipulate the robot reference frames, this class is responsible for creation, change
    and remove the tool and workspace reference frames.
    This class too is responsible for moving the robot in the tool reference frames.
    """

    def __init__(self, api_context, cao_robot):
        """
        Constructor of the class ReferenceFrames.

        Args:
            api_context: DensoRobot API context the object denso
            cao_robot: The low_level robot object to sendo request from the controller
        """
        self.api_context = api_context
        self.__cao_robot = cao_robot

        # Tool Reference
        self.__tools_tags_reference = {}
        self.__default_tool_tag = "MECHANICAL_INTERFACE"
        self.__current_tool_tag = self.default_tool_tag
        self.__current_tool_offset3d = Offset3D(0, 0, 0, 0, 0, 0)

        # Workspace Reference
        self.__default_workspace = 0, Offset3D(0, 0, 0, 0, 0, 0)
        self.__work_tags_reference = {}
        self.__current_work_tag = self.__default_workspace[0]
        self.__current_work_offset3d = self.__default_workspace[1]

    @property
    def default_tool_tag(self) -> str:
        return self.__default_tool_tag

    @property
    def default_workspace(self) -> int:
        return self.__default_workspace[0]

    @property
    def current_tool(self) -> tuple:
        return self.__current_tool_tag, self.__current_tool_offset3d

    @property
    def current_work(self):
        return self.__current_work_tag, self.__current_work_offset3d

    @property
    def tools_tags_reference(self):
        return self.__tools_tags_reference

    @property
    def work_tags_reference(self):
        return self.__work_tags_reference

    def __change_reference(self, option_change: str):
        """
        This method is responsible to change a reference for the robot, this method changes the reference for the robot
        tool or workspace, depends on a change option.
        """
        self.__cao_robot.change(option_change)

    def __check_if_workspace_already_exists(self, number_workspace: int):
        """
        This method is responsible to check if the workspace exists.
        Args:
            number_workspace: The workspace number to check.

        Returns:
            bool: True if the workspace exists, False otherwise.
        """
        if str(number_workspace) in self.__work_tags_reference.keys():
            return True

        return False

    @verify_take_arm
    def create_tool_reference(self, offset_base: Offset3D, tag: str) -> bool:
        """
        Creates a tool reference with specific offsets for each Cartesian axis (X, Y, Z) based on a given base offset.

        Note: See manual in RC8UserManuals_2201_en/en/001944.html for more information about creating a definition
              of tools.

        Args:
            offset_base (Offset3D): The base offset values (position and rotation) for defining the tool.
            tag (str): A unique identifier for the tool being created for future uses

        Returns:
            bool: True if the task was executed successfully, False otherwise.

        Raises:
            DensoExceptionHandler: If an error occurs during the command execution.
            MemoryError: If the maximum number of too references has been reached
        """
        offset_for_move_x = Offset3D(
            offset_base.x, offset_base.y, offset_base.z, offset_base.rx, offset_base.ry + 90, offset_base.rz
        )
        offset_for_move_y = Offset3D(
            offset_base.x, offset_base.y, offset_base.z, offset_base.rx - 90, offset_base.ry, offset_base.rz
        )
        offset_for_move_z = offset_base

        number_base = len(self.__tools_tags_reference.keys()) * 3 + 1
        if number_base < 63:
            elements = [
                (CartesianAxis.X, number_base, offset_for_move_x),
                (CartesianAxis.Y, number_base + 1, offset_for_move_y),
                (CartesianAxis.Z, number_base + 2, offset_for_move_z),
            ]

            self.__tools_tags_reference[tag] = {}
            for axis, num, offset in elements:
                self.__cao_robot.execute(RobotExecuteEnum.SetToolDef, [num, str(offset)])
                self.__tools_tags_reference[tag][axis] = f"Tool{num}"

            return True

        else:
            raise MemoryError("The max number of tool variables has been reached")

    @verify_take_arm
    def set_current_tool_by_tag(self, tag: str) -> bool:
        """
        Change the current tool used for movement in tool reference.

        Returns:
            bool: True if the Change was executed successfully, False otherwise.
        """
        if tag in self.__tools_tags_reference.keys():
            self.__current_tool_tag = tag
            self.__change_reference(f"{self.__tools_tags_reference[tag][CartesianAxis.Z]}")
            return True

        else:
            print("This tag is not in memory")
            return False

    # TODO: rever a necessidade dessa função de saber qual a tool reference que esta sendo usada vindo diretamente da
    #  controladora
    def get_current_tool_on_memory(self) -> tuple:
        """
        Method responsible to get the actual tool reference on robot.

        Returns:
            tuple: The number of the current tool reference and the Object offset 3d on the specifics sizes
        """
        number_tool = self.__cao_robot.execute(RobotExecuteEnum.CurTool, None)

        return number_tool, Offset3D(*self.__cao_robot.execute(RobotExecuteEnum.GetToolDef, number_tool))

    @verify_motor_on
    def move_in_tool_reference(self, axis: CartesianAxis, linear_step: int | float) -> bool:
        """
        Moves the robot along a specified Cartesian axis using the current tool as a reference.

        This method executes a movement along the given `axis` (X, Y, or Z) using a step value in `millimeters`,
        adjusted by the current tool reference.
        It switches to the tool defined for the specified axis, performs the movement,
        and then restores the previous tool configuration.

        Args:
            axis (CartesianAxis): The axis along which the robot should move (X, Y, or Z).
            linear_step (int | float): The step value to move along the axis.
            Positive values indicate forward movement, while negative values indicate backward movement.

        Returns:
            bool: True if the task was executed successfully, False otherwise.

        Raises:
            DensoExceptionHandler: If an error occurs during the movement execution.
        """

        valid_parameters = isinstance(axis, CartesianAxis) and (
            isinstance(linear_step, float) or isinstance(linear_step, int)
        )

        if not valid_parameters:
            raise TypeError(
                "Expected types CartesianAxis and int/float, but was received:", type(axis), type(linear_step)
            )

        desired_tool = self.__tools_tags_reference[self.__current_tool_tag][axis]
        self.__cao_robot.change(desired_tool)

        linear_step *= -1

        self.__cao_robot.execute(RobotExecuteEnum.Depart, [1, "@P " + str(linear_step)])

        self.__change_reference(f"{self.__tools_tags_reference[self.__current_tool_tag][CartesianAxis.Z]}")

        return True

    @verify_motor_on
    def rotate_in_tool_reference(self, axis: CartesianAxis, angle_step: int | float) -> bool:
        """
        Rotate the robot along a specified Cartesian axis using the current tool as a reference.

        This method executes a movement along the given `axis` (X, Y, or Z) using a step value in `degrees`,
        adjusted by the current tool reference.
        It switches to the tool defined for the specified axis, performs the movement,
        and then restores the previous tool configuration.

        Args:
            axis (CartesianAxis): The axis along which the robot should move (X, Y, or Z).
            angle_step (int | float): The step value to move along the axis.
            Positive values indicate forward movement, while negative values indicate backward movement.

        Returns:
            bool: True if the task was executed successfully, False otherwise.

        Raises:
            DensoExceptionHandler: If an error occurs during the movement execution.
        """
        valid_parameters = isinstance(axis, CartesianAxis) and (
            isinstance(angle_step, float) or isinstance(angle_step, int)
        )

        if not valid_parameters:
            raise TypeError(
                "Expected types CartesianAxis and int/float, but was received:", type(axis), type(angle_step)
            )

        desired_tool = self.__tools_tags_reference[self.__current_tool_tag][axis]
        self.__cao_robot.change(desired_tool)

        self.__cao_robot.execute(RobotExecuteEnum.RotateH, [angle_step, "@P"])

        self.__change_reference(f"{self.__tools_tags_reference[self.__current_tool_tag][CartesianAxis.Z]}")

        return True

    @verify_take_arm
    def create_workspace_reference(self, workspace: Offset3D, number_workspace: int):
        """
        Creates a workspace reference with specific offsets for each Cartesian axis (X, Y, Z, rX, rY, rZ) based on a
        given base offset.

        Note: See manual in RC8UserManuals_2201_en/en/001944.html for more information about creating a definition
              of workspace.

        Args:
            number_workspace (int): The number of workspaces to choice the number is between 1-8
            workspace (Offset3D): The base offset values (position and rotation) for defining the tool.

        Returns:
            bool: True if the task was executed successfully, False otherwise.

        Raises:
            DensoExceptionHandler: If an error occurs during the command execution.
            IndexError: If the workspace is out of range.
            TypeError: If the workspace is not an offset 3D instance.
        """
        if not has_reference_by_type(CAOReferenceType.WORK, number_workspace):
            raise IndexError(f"Variable number out of range for type: {CAOReferenceType.WORK.name}")

        if not isinstance(workspace, Offset3D):
            raise TypeError("Expected Offset3D, but was received:", type(workspace))

        if self.__check_if_workspace_already_exists(number_workspace):
            raise ValueError(f"Workspace {number_workspace} is already defined")
        self.__work_tags_reference[f"{number_workspace}"] = workspace
        print(f"Work{number_workspace}", str(self.__work_tags_reference[str(number_workspace)]))
        self.__cao_robot.execute(
            RobotExecuteEnum.SetWorkDef,
            [f"{number_workspace}", str(self.__work_tags_reference[str(number_workspace)])],
        )

    @verify_take_arm
    def set_current_workspace(self, number_workspace: int):
        """
        This method is responsible for changing the current workspace of the robot use.

        The workspace is the center of cartesian axes from the base, when you change this atribute change the reference
        for all the Pose positions and Translations.

        Args:
            number_workspace (int | str): The number of workspace to choice the number is between 1-8 or default
                                          workspace.

        Returns:
            bool: True if the task was executed successfully, False otherwise.

        Raises:
            DensoExceptionHandler: If an error occurs during the command execution.

        """
        if (
            not has_reference_by_type(CAOReferenceType.WORK, number_workspace)
            and number_workspace != self.__default_workspace[0]
        ):
            raise IndexError(f"Variable number out of range for type: {CAOReferenceType.WORK.name}")

        if number_workspace != self.__default_workspace[0]:
            self.__current_work_tag = number_workspace
            self.__current_work_offset3d = self.__work_tags_reference[str(number_workspace)]

        return self.__cao_robot.change(f"{CAOReferenceType.WORK}{number_workspace}")

    def get_current_workspace(self):
        """
        This method is responsible for changing the current workspace of the robot use.

        The workspace is the center of cartesian axes from the base, when you change this atribute change the reference
        for all the Pose positions and Translations.

        Returns:
            tuple:
            Return the number of actual workspace reference, and the attributes referente to this workspace.

        Raises:
            DensoExceptionHandler: If an error occurs during the command execution.
            IndexError: If the workspace is out of range.
        """
        workspace_number = self.__cao_robot.execute(RobotExecuteEnum.CurWork, None)
        workspace = self.get_workspace_by_number(workspace_number)
        return workspace_number, str(workspace)

    def get_workspace_by_number(self, number_workspace):
        """
        This method is responsible for changing the current workspace of the robot use.

        The workspace is the center of cartesian axes from the base, when you change this atribute change the reference
        for all the Pose positions and Translations.

        Args:
            number_workspace (int): The number of workspace to choice the number is between 1-8

        Returns:
            bool: True if the task was executed successfully, False otherwise.

        Raises:
            DensoExceptionHandler: If an error occurs during the command execution.
            IndexError: If the workspace is out of range.
        """
        if not has_reference_by_type(CAOReferenceType.WORK, number_workspace):
            raise IndexError(f"Variable number out of range for type: {CAOReferenceType.WORK.name}")

        offset3d = Offset3D(*self.__cao_robot.execute(RobotExecuteEnum.GetWorkDef, str(number_workspace))[0:-1])
        return offset3d

    def remove_workspace(self, number_workspace: int) -> bool:
        """
        This method is responsible to remove a specific workspace if the same is not in use.
        Do not confuse with the CAO workspace, this method is responsible to remove the workspace from the memory of the
        robot.

        Args:
            number_workspace (int): The number of workspace to choice the number is between 1-8.

        Returns:
            bool: True if the task was executed successfully.

        Raises:
            IndexError: If the workspace is out of range.
            IndexError: If the workspace is not defined.
        """
        if not has_reference_by_type(CAOReferenceType.WORK, number_workspace):
            raise IndexError(f"Variable number out of range for type: {CAOReferenceType.WORK.name}")

        if not self.__check_if_workspace_already_exists(number_workspace):
            raise IndexError(f"Workspace {number_workspace} is not already defined")

        if number_workspace == self.current_work[0]:
            raise RuntimeError(f"Workspace {number_workspace} is currently in use")

        self.__cao_robot.execute(RobotExecuteEnum.SetWorkDef, [str(number_workspace), str(Offset3D(0, 0, 0, 0, 0, 0))])
        self.__work_tags_reference.pop(f"{number_workspace}")
        return True

    @staticmethod
    def is_within_zone(exclusion_zone: Zone, position: Vector) -> bool:
        """
        Verify if the position is inside the exclusion zone.

        Args:
            exclusion_zone (Zone): The exclusion zone to be verified.
            position (Vector): The position to be verified [x, y, z].

        Returns:
            bool: True if the position is inside the exclusion zone, False otherwise.

        Raises:
            NotImplementedError: If the method is not implemented by the subclass.
        """
        return exclusion_zone.is_contained(position)
