import numpy as np

from aether_rdk.high_level.reference_frames.zone import Zone


class Sphere(Zone):
    """
    Class that defines a sphere in the robot's coordinate system.
    """

    def __init__(self, reference_zone, radius):
        """
        Defines a sphere with reference and radius.

        Args:
            reference_zone: Center of the sphere [x, y, z] in the robot's coordinate system.
            radius: Radius of the sphere.
        """
        super().__init__(reference_zone)
        self.radius = radius

    def is_contained(self, position):
        """
        Verify if the position is inside the sphere.

        Args:
            position: the position to be verified [x, y, z].

        Returns:
            True if the position is inside the sphere, False otherwise.
        """
        position = np.array(position)
        distance = np.linalg.norm(position - self.reference_zone)
        return distance <= self.radius
