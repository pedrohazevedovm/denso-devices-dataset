import numpy as np


class Zone:
    """Base class for exclusion zones."""

    def __init__(self, reference_zone):
        """
        Defines the reference position for the zone.

        Args:
            reference_zone: Reference point [x, y, z] in the robot's coordinate system.
        """
        self.reference_zone = np.array(reference_zone)

    def is_contained(self, position):
        """
        Should verify if the position is inside the zone.

        Should be implemented by the subclasses.

        Args:
            position: Position to be verified [x, y, z].
        """
        raise NotImplementedError
