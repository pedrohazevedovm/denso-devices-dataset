from enum import Enum


class MoveInterpolation(Enum):
    """
    When the robot arm moves, there is not just one path. Various paths can be created with the operation of each axis.
    The robot can be controlled so that it creates line or circle paths.

    POINT_TO_POINT: This motion moves the fastest.
    TCP point track is not considered.

    LINEAR: Linear interpolation motion.
    TCP point moves from the current position to the target position linearly at constant speed in other than
    acceleration/deceleration areas.

    CIRCULAR: Circular interpolation motion.
    The robot moves along the circular arc consisting of the current position, relay position and target position in
    order of the current position → relay position → target position.
    The robot moves at constant speed in other than acceleration/deceleration areas. Refer to "Move C."

    FREE_CURVE: Free curve interpolation motion.
    The robot moves at constant speed along a smooth curve crossing the registered point. Refer to "Move S."

    For more information, consult the page RC8UserManuals_2201_en/en/000207.html.

    """
    POINT_TO_POINT = 1      # P | PTP
    LINEAR = 2              # L
    CIRCULAR = 3            # C
    FREE_CURVE = 4          # F


class PassStartDisplacement(Enum):
    """
    Pass start displacement specifies the time to start the next line instruction along the way of a motion by a
    motion statement toward a target position.

    Integer type data are designated in the pass start displacement format as a target position option of
    the motion statement.
    The distance to the target position is specified in millimeters.

    END_MOTION: Use the time when the command position reaches to the target position.

    PASS_MOTION: The next line is executed once deceleration starts. This may also be described as "@P."

    ENCODER_VALUE: The next line is executed once it is confirmed that the encoder value (current position) reaches
    to the target position. This may also be described as "@E."

    ENCODER_VALUE_AT_C: Execute the next line when the position and posture of the tool end, which have been
    coordinate-converted based on the encoder value, has arrived at the target position. This may also be described
    as "@C."

    If the user has doubts about the pass start displacement, it is recommended to consult the
    page RC8UserManuals_2201_en/en/000519.html for more information.

    """
    END_MOTION = 0
    PASS_MOTION = -1
    ENCODER_VALUE = -2
    ENCODER_VALUE_AT_C = -6

class DensoDatatypes(Enum):
    """
    The data types that can be used in the robot controller.
    P is a Pose, T is a Homogeneous Translation, J is a Joint, and V is a Vector.
    """
    P = 0
    T = 1
    J = 2
    V = 3
