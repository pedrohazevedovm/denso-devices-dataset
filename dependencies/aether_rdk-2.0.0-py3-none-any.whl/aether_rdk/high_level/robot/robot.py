import numpy as np

from aether_rdk.cao import ControllerExecuteEnum, RobotExecuteEnum
from aether_rdk.datatypes import (
    CAOVariableType,
    DensoHomogeneousTranslation,
    HomogeneousTranslation,
    Joint,
    Pose,
    Vector,
)
from aether_rdk.high_level.robot.move_enum import DensoDatatypes, MoveInterpolation, PassStartDisplacement
from aether_rdk.high_level.utils import has_variable_by_type, in_numeric_range, validate_numeric_type
from aether_rdk.utils import MetaSingleton, error_handler_cls, verify_motor_on, verify_take_arm


@error_handler_cls
class Robot:
    """
    This class provides a high-level interface for controlling a robot's movements and operations using the Denso API.
    It encapsulates motor control, joint and pose movements, and utility functions to manage the robot's state.

    Attributes:
        api_context: Provides context and access to higher-level functions of the API.
        motor_enabled (bool): Indicates whether the robot's motor is currently enabled.
    """

    def __init__(self, api_context, cao_controller, cao_robot):
        """
        The constructor for the Robot class.

        Args:
            api_context: DensoRobot object to take the context of superior class
            cao_controller: CaoController object to execute commands
            cao_robot: CaoRobot object to execute commands
        """
        self.api_context = api_context
        self.__cao_robot = cao_robot
        self.__cao_controller = cao_controller

        self.__lock_status = MetaSingleton.instances["@LOCK"]

        # Caso queiramos rodar o teste usando o lock e depois o robô real, devemos mudar essa variável
        if self.__lock_status.value:
            self.__motor_enabled = self.__lock_status
        else:
            self.__motor_enabled = MetaSingleton.instances["@SERVO_ON"]

    @property
    def motor_enabled(self):
        """
        Property corresponding to motor is enabled

        Returns:
            bool: True if the motor is enabled, False otherwise
        """
        return self.__motor_enabled.value

    @verify_take_arm
    def motor_on(self) -> bool:
        """
        Enable the robot motor.

        Returns:
            bool: The return status of the command.
            True if the motor was enabled, False if the motor was already enabled.
        """
        if self.motor_enabled:
            print("Motor already enabled")
            return False

        self.__cao_robot.execute(RobotExecuteEnum.Motor, [1, 0])
        return True

    @verify_take_arm
    def motor_off(self) -> bool:
        """
        Disable the robot motor.

        Returns:
            bool: The return status of the command.
            True if the motor was disabled, False if the motor was already disabled.
        """
        if not self.motor_enabled:
            print("Motor not enabled to turn off")
            return False

        self.__cao_robot.execute(RobotExecuteEnum.Motor, [0, 0])
        self.api_context.give_arm()
        return True

    @verify_motor_on
    def move_joints(
        self,
        command: Joint,
        interpolation: int | MoveInterpolation = 1,
        pass_start_displacement: int | PassStartDisplacement = -2,
        motion_option="",
    ) -> bool:
        """
        Move the robot to a position defined by the joint values.

        Args:
            command: The joint values to move the robot.
            interpolation: The interpolation type to move the robot.
                           Default is 1 (POINT_TO_POINT).
            pass_start_displacement: The pass start displacement value to move the robot.
                                     Default is -2 (ENCODER_VALUE).
            motion_option: The motion option to move the robot, default is "".
                           Check the robot manual for more information.

        Returns:
            bool: The return status of the command.
            True if the movement was successful, False if the type of the command is not a Joint.
        """
        if not isinstance(command, Joint):
            raise TypeError(f"Expected Joint, but {type(command)} was received.")

        self.__cao_robot.move(
            interpolation,
            [
                [command.joint_1, command.joint_2, command.joint_3, command.joint_4, command.joint_5, command.joint_6],
                DensoDatatypes.J.value,
                pass_start_displacement,
            ],
            motion_option,
        )

        return True

    @verify_motor_on
    def move_pose(
        self,
        command: Pose,
        interpolation: int | MoveInterpolation = 1,
        pass_start_displacement: int | PassStartDisplacement = -2,
        motion_option="",
    ) -> bool:
        """
        Move the robot to a position defined by the pose values.
        Args:
            command: The pose values to move the robot.
            interpolation: The interpolation type to move the robot.
                           Default is 1 (POINT_TO_POINT).
            pass_start_displacement: The pass start displacement value to move the robot.
                                     Default is -2 (ENCODER_VALUE).
            motion_option: The motion option to move the robot, default is "".
                           Check the robot manual for more information.

        Returns:
            bool: The return status of the command.
            True if the movement was successful, False if the type of the command is not a Pose.
        """
        if not isinstance(command, Pose):
            raise TypeError(f"Expected Pose, but {type(command)} was received.")

        self.__cao_robot.move(
            interpolation,
            [
                [command.x, command.y, command.z, command.rx, command.ry, command.rz, command.fig],
                DensoDatatypes.P.value,
                pass_start_displacement,
            ],
            motion_option,
        )

        return True

    @verify_motor_on
    def move_by_homogeneous_translation(
        self,
        command: HomogeneousTranslation,
        interpolation: int | MoveInterpolation = 1,
        pass_start_displacement: int | PassStartDisplacement = -2,
        motion_option="",
    ) -> bool:
        """
        Move the robot to a position defined by the homogeneous translation values.

        Args:
            command: The homogeneous translation values to move the robot.
            interpolation: The interpolation type to move the robot.
                           Default is 1 (POINT_TO_POINT).
            pass_start_displacement: The pass start displacement value to move the robot.
                                     Default is -2 (ENCODER_VALUE).
            motion_option: The motion option to move the robot, default is "".
                           Check the robot manual for more information.

        Returns:
            bool: The return status of the command.
            True if the movement was successful, False if the type of the command is not a HomogeneousTranslation
            or HomogeneousTranslation.
        """
        if not isinstance(command, HomogeneousTranslation):
            raise TypeError(f"Expected HomogeneousTranslation, but {type(command)} was received.")

        command = command.to_dht()

        self.__cao_robot.move(
            interpolation,
            [
                [
                    command.x,
                    command.y,
                    command.z,
                    command.ox,
                    command.oy,
                    command.oz,
                    command.ax,
                    command.ay,
                    command.az,
                    command.fig,
                ],
                DensoDatatypes.T.value,
                pass_start_displacement,
            ],
            motion_option,
        )

        return True

    @verify_motor_on
    def move_by_variable(
        self,
        cao_type: CAOVariableType,
        number: int | str,
        interpolation: int | MoveInterpolation = 1,
        pass_start_displacement: int | PassStartDisplacement = -2,
        motion_option="",
    ) -> bool:
        """
        Move the robot to a position stored in the selected variable.

        Args:
            cao_type (CAOVariableType): The type of the variable (P, T or J).
            number (int): The number of the variable.
            interpolation: The interpolation type to move the robot.
                           Default is 1 (POINT_TO_POINT).
            pass_start_displacement: The pass start displacement value to move the robot.
                                     Default is -2 (ENCODER_VALUE).
            motion_option: The motion option to move the robot, default is "".
                            Check the robot manual for more information.

        Returns:
            bool: The return status of the command. True if the movement was successful, False otherwise.
        """
        if not (
            isinstance(cao_type, CAOVariableType)
            and isinstance(number, (int, str))
            and has_variable_by_type(cao_type, number)
        ):
            raise TypeError(
                f"Expected types CAOVariableType and int, but was received " f"{type(cao_type)} and {type(number)}"
            )

        if cao_type in (CAOVariableType.J, CAOVariableType.P, CAOVariableType.T, CAOVariableType.V):
            self.__cao_robot.move(interpolation, [number, str(cao_type), pass_start_displacement], motion_option)
            return True

    @verify_motor_on
    def move_single_joint(self, joint_number: int, value: int) -> bool:
        """
        Move a single joint to a specific value.

        Args:
            joint_number: The joint to move.
            value: The value to move the joint to.

        Returns:
            bool: The return status of the command.
                  True if the joint was moved, False if the joint is not in range or not an int.
        """
        if joint_number not in range(1, 7):
            raise ValueError("Choose a joint number between 1 and 6.")

        actual_joints = self.get_joints().to_list()
        actual_joints[int(joint_number) - 1] = int(value)

        self.__cao_robot.move(1, [actual_joints, DensoDatatypes.J.value, "@E"], "")

        return True

    @verify_motor_on
    def move_by_offset(self, offset_position: Vector) -> bool:
        """
        moves the robotic arm in relation to the current position of the gripper, considering the current orientation.

        Args:
            offset_position: List of offsets [x, y, z].

        Returns:
            bool: True if the motion command was successful, False otherwise.
        """
        if not isinstance(offset_position, Vector):
            raise TypeError(f"Expected Vector, but {type(offset_position)} was received.")

        actual_pose = self.get_pose()
        actual_orientation = actual_pose.to_list()[3:6]

        actual_t_matrix = self.get_homogeneous_translation()
        actual_t_matrix = actual_t_matrix.to_np_array()

        x_offset, y_offset, z_offset = offset_position.to_list()
        position_offset = np.array([x_offset, y_offset, z_offset, 1]).reshape(4, 1)

        new_point = actual_t_matrix @ position_offset
        new_position = new_point[:3].flatten()

        # Command the robot to move to the new pose
        new_pose = Pose(*new_position, *actual_orientation, actual_pose.fig)
        success = self.move_pose(new_pose)

        return success

    @verify_motor_on
    def move_to_home(self) -> bool:
        """
        Move the robot to the home position.

        The home positions are defined by the authors of this API.

        Returns:
            bool: The return status of the command.
            True if the robot was moved to the home position, False otherwise.
        """
        home_position = Pose(400.00, 0, 315.00, -180.00, 0.00, 90.00, 5)

        self.__cao_robot.move(
            1,
            [
                [
                    home_position.x,
                    home_position.y,
                    home_position.z,
                    home_position.rx,
                    home_position.ry,
                    home_position.rz,
                    home_position.fig,
                ],
                DensoDatatypes.P.value,
                "@E",
            ],
            "",
        )

        return True

    @verify_motor_on
    def move_to_zero(self) -> bool:
        """
        Move the robot to the joint zero position.

        Returns:
            bool: The return status of the command.
            True if the robot was moved to the joint zero position, False otherwise.
        """
        jz = Joint(0, 0, 0, 0, 0, 0)

        self.__cao_robot.move(
            1,
            [[jz.joint_1, jz.joint_2, jz.joint_3, jz.joint_4, jz.joint_5, jz.joint_6], DensoDatatypes.J.value, "@E"],
            "",
        )

        return True

    def get_joints(self) -> Joint:
        """
        Get the current robot position in joint values.

        Returns:
            Joint: The current robot position in joint values in Joint object format.
        """
        joints = self.__cao_robot.execute(RobotExecuteEnum.CurJnt, [])

        return Joint(
            round(joints[0], 3),
            round(joints[1], 3),
            round(joints[2], 3),
            round(joints[3], 2),
            round(joints[4], 2),
            round(joints[5], 2),
        )

    def get_pose(self) -> Pose:
        """
        Get the current robot position in pose values.

        Returns:
            Pose: The current robot position in pose values in Pose object format.
        """
        pose = self.__cao_robot.execute(RobotExecuteEnum.CurPos, [])

        return Pose(
            round(pose[0], 3),
            round(pose[1], 3),
            round(pose[2], 3),
            round(pose[3], 3),
            round(pose[4], 3),
            round(pose[5], 2),
            int(pose[6]),
        )

    def get_homogeneous_translation(self) -> HomogeneousTranslation:
        """
        Get the current robot position in homogeneous translation values.

        Returns:
            HomogeneousTranslation: The current robot position in homogeneous translation values.
        """
        # The returned figure value is float, so it is necessary to convert it to int.
        dht_response = self.__cao_robot.execute(RobotExecuteEnum.CurTrn, [])
        round_response = tuple(round(i, 3) for i in dht_response)

        round_response = round_response[0:-1] + (int(round_response[-1]),)

        dht = DensoHomogeneousTranslation.from_list(round_response)
        ht = HomogeneousTranslation.from_dht(dht)

        return ht

    def set_arm_speed(self, speed, accel, decel) -> bool:
        """
        Set the robot arm external speed.

        Args:
            speed: The speed value.
            accel: The acceleration value.
            decel: The deceleration value.

        Returns:
            bool: The return status of the command.
            True if the speed was set, False if the value is not in range or not a float or int.
        """
        param_list = [speed, accel, decel]

        if validate_numeric_type(param_list) and in_numeric_range(param_list, 1, 100):
            self.__cao_robot.execute(RobotExecuteEnum.ExtSpeed, param_list)
            return True
        else:
            raise ValueError("The values are not in the range [1, 100] or are not float or int.")

    def get_current_arm_speed(self) -> tuple | None:
        """
        Get the current robot arm external speed.

        Returns:
            tuple: The current robot arm external speed, acceleration, and deceleration values.
        """
        speed = self.__cao_robot.execute(RobotExecuteEnum.CurExtSpd, 0)
        accel = self.__cao_robot.execute(RobotExecuteEnum.CurExtAcc, 0)
        decel = self.__cao_robot.execute(RobotExecuteEnum.CurExtDec, 0)
        return speed, accel, decel

    def emergency_stop(self) -> bool:
        """
        Stop the robot movement immediately.

        Returns:
            bool: The return status of the command.
            True if the emergency stop was successful, False otherwise.
        """
        self.__cao_controller.execute(ControllerExecuteEnum.SuspendAll)
        self.__cao_controller.execute(ControllerExecuteEnum.KillAll)
        return True

    def get_current_figure(self) -> int:
        """
        Get the current robot figure.

        Returns:
            int: The current robot figure.
        """
        return self.__cao_robot.execute(RobotExecuteEnum.CurFig, [])

    def is_reachable(self, robot_command: Joint | Pose | HomogeneousTranslation) -> bool:
        """
        Check if the robot command is out of range.

        Args:
            robot_command: The robot command to check if it is out of range.
                           This command can be a Joint, Pose, or HomogeneousTranslation object.

        Returns:
            bool: The return status of the command.
                  True if the command is reachable, False otherwise.
        """
        if not isinstance(robot_command, (Joint, Pose, HomogeneousTranslation)):
            print(f"Expected Robot command types, but {type(robot_command)} was received")
            return False

        if isinstance(robot_command, HomogeneousTranslation):
            robot_command = robot_command.to_dht()

        str_command = str(robot_command)

        res = self.__cao_robot.execute(RobotExecuteEnum.OutRange, str_command)
        return res == 0
