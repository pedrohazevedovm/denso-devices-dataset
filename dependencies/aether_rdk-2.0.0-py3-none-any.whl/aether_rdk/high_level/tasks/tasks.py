from aether_rdk.cao.enumerates import TaskExecutionMode, TaskGetStatus, TaskStopMode
from aether_rdk.utils import MetaSingleton, error_handler_cls


@error_handler_cls
class Tasks:
    """
    A class for managing task-related operations on a robot controller.

    The `Tasks` class provides methods for interacting with and managing files
    and tasks on a robot controller.
    It supports operations such as file creation, retrieval, and modification, as well as task execution,
    status monitoring, and stopping or resuming tasks.

    Attributes:
        api_context: The API context used for the tasks.
    """

    def __init__(self, api_context, cao_controller):
        """
        Initializes the Tasks class with the given API context and robot controller.

        Args:
            api_context: The API context to be used for the tasks.
            cao_controller: The robot controller to be used for the tasks.
        """
        self.api_context = api_context
        self.__cao_controller = cao_controller

        self.__FILE_TYPE = [".pcs", ".h"]

    def has_file_in_controller(self, file_name: str) -> bool:
        """
        Checks if a file exists in the robot controller.

        Parameters:
            file_name (str): The name of the file to check.

        Returns:
            bool: True if the file exists, False otherwise.

        Raises:
            DensoExceptionHandler: If an exception occurs during the check process.
        """
        current_files = self.__cao_controller.file_names
        return file_name in current_files

    def __file_extension_check(self, file_name: str):
        """
        This method is used to check if the file name has the expected extension.

        Args:
            file_name: The name of the file to be checked.

        Returns:
            bool: True if the file name has the expected extension, False otherwise.
        """
        for ext in self.__FILE_TYPE:
            if ext in file_name:
                return True

        raise ValueError(f"File name extension not expected! Expect: {self.__FILE_TYPE}")

    def create_file(self, file_name: str, content: str) -> bool:
        """
        Creates a file with the given file name and content in the robot controller.

        Parameters:
            file_name (str): The name of the file to be created.
            content (str): The content to be written in the file.

        Returns:
            bool: True if the file is created successfully, False otherwise.

        Raises:
            FileExistsError: If the file already exists in the controller.
            DensoExceptionHandler: If any exception occurs during the file creation process.
            ValueError: If the script_name does not have the expected file extension.
        """
        if not self.__file_extension_check(file_name):
            raise ValueError(f"File name extension not expected! Expect: {self.__FILE_TYPE}")

        if not self.has_file_in_controller(file_name):
            file_obj = self.__cao_controller.controller_add_file(file_name, "@Create=1")
            file_obj.value = content
            return True
        else:
            raise FileExistsError(f"File {file_name} already exists in the controller!")

    def update_file(self, file_name: str, content: str) -> bool:
        """
        Override the full content of a file in the robot controller.

        Parameters:
            file_name (str): The name of the file to be updated.
            content (str): The new content to be written to the file.

        Returns:
            bool: True if the file was successfully updated, False otherwise.

        Raises:
            FileNotFoundError: If the file does not exist in the robot controller.
            DensoExceptionHandler: If an exception occurs during the update process.
        """
        # Create a symbolic link with DCOM or get of dict of objects links
        if self.has_file_in_controller(file_name):
            if file_name in MetaSingleton.instances.keys():
                file_obj = MetaSingleton.instances[file_name]
            else:
                file_obj = self.__cao_controller.controller_add_file(file_name)

            file_obj.value = content
            return True
        else:
            raise FileNotFoundError(f"File {file_name} not found in controller!")

    def get_file_content(self, file_name: str) -> str:
        """
        Retrieves the content of a file from the robot controller.

        Parameters:
            file_name (str): The name of the file to retrieve.

        Returns:
            str: The content of the file.

        Raises:
            FileNotFoundError: If the file is not found in the robot controller.
            DensoExceptionHandler: If any other exception occurs during the retrieval process.
        """
        if self.has_file_in_controller(file_name):
            if file_name in MetaSingleton.instances.keys():
                file_obj = MetaSingleton.instances[file_name]
            else:
                file_obj = self.__cao_controller.controller_add_file(file_name)
            return file_obj.value
        else:
            raise FileNotFoundError(f"File {file_name} not found in controller!")

    def get_task_status(self, task_name: str):
        """
        Get the status of a task with the given task name

        Args:
            task_name: The name of the script to execute.

        Returns:
            int: The status of the task.

        """
        if not (self.__file_extension_check(task_name) and self.has_file_in_controller(task_name)):
            raise FileNotFoundError(f"Script {task_name} not found or not available to execute")

        task_name = task_name.replace(".pcs", "")

        if task_name in MetaSingleton.instances.keys():
            task_obj = MetaSingleton.instances[task_name]
        else:
            task_obj = self.__cao_controller.controller_add_task(task_name)

        status = task_obj.execute(TaskExecutionMode.GetStatus)
        status = TaskGetStatus(status)

        return status

    def start_task(self, script_name: str, execution_mode: TaskExecutionMode | int = 1) -> bool:
        """
        Execute a script task with the given script name and execution mode.

        This method corresponds to Start method in CAO Task Manager.

        Parameters:
            script_name (str): The name of the script to execute.
            execution_mode (TaskExecutionMode): The mode in which the task should be executed.

        Returns:
            bool: True if the task was executed successfully, False otherwise.

        Raises:
            ValueError: If the script_name does not have the expected file extension.
            FileNotFoundError: If the script file is not found or not available for execution.
            TypeError: If the provided mode is not an instance of TaskExecutionMode.
            DensoExceptionHandler: If an exception occurs during task execution.
        """
        if not (self.__file_extension_check(script_name) and self.has_file_in_controller(script_name)):
            raise FileNotFoundError(f"Script {script_name} not found or not available to execute")

        if not isinstance(execution_mode, (TaskExecutionMode, int)):
            raise TypeError(f"Expected TaskExecutionMode, but {type(execution_mode)} was received")

        script_name = script_name.replace(".pcs", "")

        if script_name in MetaSingleton.instances.keys():
            task_obj = MetaSingleton.instances[script_name]
        else:
            task_obj = self.__cao_controller.controller_add_task(script_name)

        task_obj.start(execution_mode.value)

        return True

    def resume_task(self, task_name: str) -> bool:
        """
        Resume a task with the given task name.

        Args:
            task_name (str): The name of the script to stop.

        Returns:
            bool: True if the task was paused successfully, False otherwise.
        """
        if not (self.__file_extension_check(task_name) and self.has_file_in_controller(task_name)):
            raise FileNotFoundError(f"Script {task_name} not found or not available to execute")

        task_status = self.get_task_status(task_name)

        if task_status == TaskGetStatus.TASK_NON_EXISTENT.value:
            raise ValueError(f"Task {task_name} does not exist")

        if task_status == TaskGetStatus.TASK_STEPSTOP.value or TaskGetStatus.TASK_SUSPEND.value:
            start_mode = TaskStopMode.STEP_STOP

            task_name = task_name.replace(".pcs", "")

            if task_name in MetaSingleton.instances.keys():
                task_obj = MetaSingleton.instances[task_name]
            else:
                task_obj = self.__cao_controller.controller_add_task(task_name)
            task_obj.start(start_mode.value)
            return True
        else:
            return False

    def stop_task(self, task_name: str, stop_mode: TaskStopMode | int = 0) -> bool:
        """
        Stop a task with the given task name.

        Parameters:
            task_name (str): The name of the script to stop.
            stop_mode: The mode in which the task should be stopped.

        Returns:
            bool: True if the task was stopped successfully, False otherwise.

        Raises:
            FileNotFoundError: If the script file is not found or not available for execution.
            DensoExceptionHandler: If an exception occurs during task stopping.
        """
        if not (self.__file_extension_check(task_name) and self.has_file_in_controller(task_name)):
            raise FileNotFoundError(f"Script {task_name} not found or not available to execute")

        if not isinstance(stop_mode, (TaskStopMode, int)):
            raise TypeError(f"Expected TaskExecutionMode, but {type(stop_mode)} was received")

        task_name = task_name.replace(".pcs", "")

        if task_name in MetaSingleton.instances.keys():
            task_obj = MetaSingleton.instances[task_name]
        else:
            task_obj = self.__cao_controller.controller_add_task(task_name)

        task_obj.stop(stop_mode.value)

        return True
