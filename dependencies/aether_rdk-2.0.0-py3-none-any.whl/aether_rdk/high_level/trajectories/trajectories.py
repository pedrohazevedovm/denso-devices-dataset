class Trajectories:
    """
    This class is responsible for implement the trajectories methods for the trajectories module.
    """

    ...
