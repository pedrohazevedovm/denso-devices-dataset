class Transformations:
    """
    Class implements the transformations that can be applied to the data.
    """

    ...
