from aether_rdk.datatypes import CAOReferenceType, CAOVariableType, HomogeneousTranslation, Joint, Pose, Vector


def has_variable_by_type(cao_type: CAOVariableType, number: int) -> bool:
    """
    Check if the variable number is in range for the variable type.

    Args:
        cao_type: The CAO Type of the variable.
        number: The number of the variable.

    Returns:
        bool: The return status of the command.
        True if the variable number is in range, False otherwise.
    """
    if cao_type == CAOVariableType.IO:
        # TODO: Check range for IO variables
        return True

    max_number = 100
    if (
        cao_type == CAOVariableType.D
        or cao_type == CAOVariableType.V
        or cao_type == CAOVariableType.T
        or cao_type == CAOVariableType.S
    ):
        max_number = 50

    has_variable = number < max_number
    return has_variable


def has_reference_by_type(cao_type: CAOReferenceType, number: int) -> bool:
    """
    Check if the reference number is in range for the reference type.
    Args:
        cao_type: The CAO Type of the reference.
        number: The number of the reference.

    Raises:
        IndexError: If the reference number is out of range.

    Returns:
        bool: The return status of the command.
        True if the reference number is in range, False otherwise.
    """
    max_number = min_number = 0

    if cao_type == CAOReferenceType.TOOL:
        max_number = 64
        min_number = 1

    elif cao_type == CAOReferenceType.WORK:
        max_number = 8
        min_number = 1
    # TODO put the area and path point here

    has_variable = min_number <= number < max_number
    return has_variable


def validate_numeric_type(value_list) -> bool:
    """
    Check if the values are float or int.

    Args:
        value_list: The list of values to check.

    Returns:
        bool: The return status of the command.
        True if the values are float or int, False otherwise.
    """
    for val in value_list:
        if not isinstance(val, float) and not isinstance(val, int):
            print(f"Expected float or int, but {type(val)} was received")
            return False

    return True


def in_numeric_range(value_list, range_min, range_max):
    """
    Check if the values are in the specified range.

    Args:
        value_list: The list of values to check.
        range_min: The minimum value of the range.
        range_max: The maximum value of the range.

    Returns:
        bool: The return status of the command.
        True if the values are in the range, False otherwise.
    """
    for val in value_list:
        if not (range_min <= val <= range_max):
            return False
    return True


def variable_in_range_by_type(cao_type: CAOVariableType, value) -> bool:
    """
    Method to check if the variable number is in range for the variable type.
    Args:
        cao_type: The CAO Type of the variable.
        value: Value of the variable.

    Returns:
        bool: True if the variable number is instance, False otherwise.
    """
    if cao_type == CAOVariableType.I:
        return isinstance(value, int)
    if cao_type == CAOVariableType.F or cao_type == CAOVariableType.D:
        return isinstance(value, float)
    if cao_type == CAOVariableType.S:
        return isinstance(value, str) and (len(value) <= 243)
    if cao_type == CAOVariableType.V:
        return isinstance(value, (tuple, Vector)) and (len(value) == 3)
    if cao_type == CAOVariableType.P:
        return isinstance(value, (tuple, Pose)) and (len(value) == 7)
    if cao_type == CAOVariableType.T:
        return isinstance(value, (tuple, HomogeneousTranslation)) and (len(value) >= 9)
    if cao_type == CAOVariableType.J:
        return isinstance(value, (tuple, Joint)) and (len(value) >= 6)
    if cao_type == CAOVariableType.IO:
        return isinstance(value, int) and (value == 0 or value == 1)
