from aether_rdk.datatypes import DensoHomogeneousTranslation, HomogeneousTranslation, Joint, Pose, Vector
from aether_rdk.datatypes.constants import CAOVariableType
from aether_rdk.high_level.utils import has_variable_by_type, variable_in_range_by_type
from aether_rdk.utils import MetaSingleton, error_handler_cls


@error_handler_cls
class Variables:
    """
    The `Variables` class provides an interface for managing variables in a Denso robotic controller.

    This class enables interaction with CAO variables of various types, allowing for retrieval and updating
    of their content while performing type-specific validation and transformation.

    Attributes:
        api_context: The context of the API for maintaining state and access to services.
    """

    def __init__(self, api_context, cao_controller):
        """
        Initializes the Variables class.

        Args:
            api_context: the context of the API.
            cao_controller: the controller to interact with the CAO.
        """
        self.api_context = api_context
        self.__cao_controller = cao_controller

    def get_variable_content(self, cao_variable_type: CAOVariableType, number: int):
        """
        Retrieves the content of a variable based on its type and number.

        Corresponding variable content based on the type:

            - For Type I: Integer
            - For Type F or D: Float
            - For Type S: String with length is less than or equal to 243
            - For Type V: Tuple with a length of 3
            - For Type P: Tuple with a length of 7
            - For Type T: Tuple with a length of 9
            - For Type J: Tuple with a length of 6
            - For Type IO: Integer with value 0 or 1

        Parameters:
            cao_variable_type (CAOVariableType): The type of the variable.
            number (int): The index of the variable.

        Returns:
            The content of the variable.

        Raises:
            TypeError: If the cao_type parameter is not of type CAOVariableType.
            IndexError: If the index is out of range for type.
            DensoExceptionHandler: If an error occurs while retrieving the variable content.
        """
        if not isinstance(cao_variable_type, CAOVariableType):
            raise TypeError(f"Expected CAOVariableType, but {type(cao_variable_type)} was received.")

        if not has_variable_by_type(cao_variable_type, number):
            raise IndexError(f"Variable number out of range for type: {cao_variable_type.name}")

        variable_key = f"{cao_variable_type}{number}"

        if variable_key in MetaSingleton.instances.keys():
            var_obj = MetaSingleton.instances[variable_key]
        else:
            var_obj = self.__cao_controller.controller_add_variable(variable_key)

        datatype_value = self.__to_datatypes(cao_variable_type, var_obj.value)

        return datatype_value

    def set_variable_content(
        self,
        cao_variable_type: CAOVariableType,
        number: int,
        new_value_datatype: int | float | str | Vector | Pose | Joint | Vector | HomogeneousTranslation,
    ) -> bool:
        """
        Set the variable content of a selected type and number with the new_value.

            - For Type I: Integer
            - For Type F or D: Float
            - For Type S: String with length is less than or equal to 243
            - For Type V: Tuple with a length of 3
            - For Type P: Tuple with a length of 7
            - For Type T: Tuple with a length of 9
            - For Type J: Tuple with a length of 6
            - For Type IO: Integer with value 0 or 1

        Parameters:
            cao_variable_type (CAOVariableType): The type of the variable.
            number (int): The number of the variable.
            new_value_datatype: The new value to assign to the variable, based on the type:

        Returns:
            bool: True if the content was set successfully, False otherwise.

        Raises:
            ValueError: If the new value does not match the requirements for the given variable type.
            IndexError: If the index is out of range for type.
            TypeError: If the provided cao_type is not an instance of CAOVariableType.
            DensoExceptionHandler: If an exception occurs while setting the variable content.
        """
        if not isinstance(cao_variable_type, CAOVariableType):
            raise TypeError(f"Expected CAOVariableType, but {type(cao_variable_type)} was received.")

        if not (
            has_variable_by_type(cao_variable_type, number)
            and variable_in_range_by_type(cao_variable_type, new_value_datatype)
        ):
            raise ValueError(
                f"Receive {new_value_datatype} for type {cao_variable_type.name}, "
                f"value does not match with the requirements"
            )

        variable_key = f"{cao_variable_type}{number}"

        if variable_key in MetaSingleton.instances.keys():
            var_obj = MetaSingleton.instances[variable_key]
        else:
            var_obj = self.__cao_controller.controller_add_variable(variable_key)

        new_value = self.__from_datatypes(cao_variable_type, new_value_datatype)
        var_obj.value = new_value

        return True

    @staticmethod
    def __to_datatypes(cao_variable_type: CAOVariableType, value):
        """
        Convert the value to the corresponding datatype based on the CAOVariableType.

        Args:
            cao_variable_type: The type of the variable.
            value: The value to convert.

        Returns:
            The value converted to the corresponding datatype.
        """
        if cao_variable_type == CAOVariableType.J:
            value = value[:-2]
            joint = Joint.from_list(value)
            return joint

        elif cao_variable_type == CAOVariableType.P:
            value = value[0:-1] + (int(value[-1]),)
            pose = Pose.from_list(value)
            return pose

        elif cao_variable_type == CAOVariableType.V:
            vector = Vector.from_list(value)
            return vector

        elif cao_variable_type == CAOVariableType.T:
            value = value[0:-1] + (int(value[-1]),)
            dht = DensoHomogeneousTranslation.from_list(value)
            ht = HomogeneousTranslation.from_dht(dht)
            return ht

        return value

    @staticmethod
    def __from_datatypes(cao_variable_type: CAOVariableType, value):
        """
        Convert the value from the corresponding datatype based on the CAOVariableType.

        Args:
            cao_variable_type: The type of the variable.
            value: The value to convert.

        Returns:
            The value converted from the corresponding datatype.
        """
        if cao_variable_type in (CAOVariableType.J, CAOVariableType.P, CAOVariableType.V):
            return value.to_list()

        elif cao_variable_type == CAOVariableType.T:
            return value.to_dht().to_list()

        return value
