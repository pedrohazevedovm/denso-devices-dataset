import os
import signal
import winreg

import win32com.client


def dec_complemented2_to_hex(val, n_bits) -> str:
    """
    Converts a decimal value to its hexadecimal representation using two's complement.

    Args:
        val (int): The decimal value to convert.
        n_bits (int): The number of bits in the representation.

    Returns:
        str: The hexadecimal representation of the input value.
    """
    return hex((val + (1 << n_bits)) % (1 << n_bits))


def get_system_installed_softwares() -> list[dict]:
    """
    Retrieves a list of installed software on the system by querying the Windows registry.

    Returns:
        list[dict]: A list of dictionaries containing the following keys:
            - "name": The display name of the software.
            - "version": The software version (or "undefined" if unavailable).
            - "publisher": The publisher of the software (or "undefined" if unavailable).

    Notes:
        - This function checks both 32-bit and 64-bit registry keys.
        - Requires administrative privileges to access certain registry hives.
    """
    flags_analyses = [
        (winreg.HKEY_LOCAL_MACHINE, winreg.KEY_WOW64_32KEY),
        (winreg.HKEY_LOCAL_MACHINE, winreg.KEY_WOW64_64KEY),
        (winreg.HKEY_CURRENT_USER, 0),
    ]
    software_list = []

    for hive, flag in flags_analyses:
        a_reg = winreg.ConnectRegistry(None, hive)
        a_key = winreg.OpenKey(a_reg, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall", 0, winreg.KEY_READ | flag)

        count_subkey = winreg.QueryInfoKey(a_key)[0]

        for i in range(count_subkey):
            software = {}
            try:
                a_subkey_name = winreg.EnumKey(a_key, i)
                a_subkey = winreg.OpenKey(a_key, a_subkey_name)
                software["name"] = winreg.QueryValueEx(a_subkey, "DisplayName")[0]

                try:
                    software["version"] = winreg.QueryValueEx(a_subkey, "DisplayVersion")[0]
                except EnvironmentError:
                    software["version"] = "undefined"
                try:
                    software["publisher"] = winreg.QueryValueEx(a_subkey, "Publisher")[0]
                except EnvironmentError:
                    software["publisher"] = "undefined"
                software_list.append(software)
            except EnvironmentError:
                continue

    return software_list


def cleanup_cao_process():
    """
    Terminates the `CAO.exe` process if running on the system.

    This function identifies the process ID (PID) of `CAO.exe` using WMI and
    sends a termination signal to the process.

    Dependencies:
        - `win32com.client`: For WMI process management.
        - `os`: For process termination.
        - `signal`: For specifying the termination signal.

    Prints:
        - A message indicating whether the process was found and terminated.
    """
    print("Terminate low_level process...")
    wmi = win32com.client.GetObject("winmgmts:")
    cao_pid = [p.ProcessId for p in wmi.InstancesOf("win32_process") if p.name == "CAO.exe"]

    if len(cao_pid) > 0:
        print("Kill process PID: ", cao_pid)
        pid = int(cao_pid[0])
        os.kill(pid, signal.SIGTERM)


def setup_network():
    """
    Placeholder function for setting up network configurations.

    This function is a stub and requires implementation.

    TODO:
        - Add logic to change network configuration based on requirements.
    """
    ...
