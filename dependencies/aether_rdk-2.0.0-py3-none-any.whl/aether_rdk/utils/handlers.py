import builtins
from functools import wraps

from aether_rdk.cao.exceptions import DensoExceptionHandler


def error_handler_cls(cls):
    """
    This function is a decorator to handle exceptions in class methods.

    This method skips the magic methods and static methods, if the method is not a static method, it will be wrapped
    with the error_handler function.

    It Is not recommended to use static methods in the denso robot API, because the static methods are not wrapped with
    the error_handler function.

    Args:
        cls: The class to be decorated.

    Returns:
        The decorated class.
    """
    for attr_name, attr_value in cls.__dict__.items():
        if callable(attr_value) and not (attr_name.startswith("__") and attr_name.endswith("__")):
            if not isinstance(attr_value, staticmethod):
                setattr(cls, attr_name, error_handler(attr_value))
    return cls


# TODO: Ver quando esse método é chamado na classe externa. La não temos api_context.
def error_handler(func):
    """
    This function is a decorator to handle exceptions in class methods.

    Args:
        func: the function to be decorated.
    Returns:
        The decorated function.
    Raises:
        DensoExceptionHandler: If an error occurs during the command execution
    """

    @wraps(func)
    def wrapper(self, *args, **kwargs):
        try:
            return func(self, *args, **kwargs)
        except Exception as e:
            self.api_context.give_arm()
            if type(e).__name__ in dir(builtins):
                raise e
            else:
                raise DensoExceptionHandler(e.args) from e

    return wrapper


def verify_connection(func):
    """
    This function is a decorator to verify if the robot is connected before executing a command.

    Args:
        func: the function to be decorated.
    Returns:
        The decorated function.
    Raises:
        DensoExceptionHandler: If an error occurs during the command execution
    """

    @wraps(func)
    def wrapper(self, *args, **kwargs):
        try:
            if self.is_connected:
                return func(self, *args, **kwargs)
            else:
                print("Robot not connected")
                return False
        except Exception as e:
            self.give_arm()
            if type(e).__name__ in dir(builtins):
                raise e
            else:
                raise DensoExceptionHandler(e.args) from e

    return wrapper


def verify_motor_on(func):
    """
    This function is a decorator to verify if the motor is enabled before executing a command.

    Args:
        func: the function to be decorated.

    Returns:
        The decorated function.

    Raises:
        DensoExceptionHandler: If an error occurs during the command execution
    """

    @wraps(func)
    def wrapper(self, *args, **kwargs):
        try:
            if self.api_context.robot.motor_enabled:
                return func(self, *args, **kwargs)
            else:
                print("Motor is not enabled")
                return False
        except Exception as e:
            self.api_context.give_arm()
            if type(e).__name__ in dir(builtins):
                raise e
            else:
                raise DensoExceptionHandler(e.args) from e

    return wrapper


# TODO: create a function on denso robot
def verify_take_arm(func):
    """
    This function is a decorator to verify if the take arm is enabled before executing a command.

    Args:
        func: the function to be decorated.

    Returns:
        The decorated function.

    Raises:
        DensoExceptionHandler: If an error occurs during the command execution
    """

    @wraps(func)
    def wrapper(self, *args, **kwargs):
        try:
            if self.api_context.is_take_arm:
                return func(self, *args, **kwargs)
            else:
                print("Take Arm is not enabled")
                return False
        except Exception as e:
            raise DensoExceptionHandler(e.args)

    return wrapper
