class MetaSingleton(type):
    instances = {}

    def __call__(cls, *args, **kwargs):
        identifier = args[1] if args else id(cls)

        if identifier not in cls.instances:
            cls.instances[identifier] = super().__call__(*args, **kwargs)
        return cls.instances[identifier]
